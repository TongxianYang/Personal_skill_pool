#ifndef __LOGGER_RC_H__
#define __LOGGER_RC_H__

/**
 * Unified debug log specification,
 * different modules to print a different label
 * and will print func name and line
 * Instructions, such as airkiss module want add a print
 * LOGE(DEBUG_TEST,"hello workld ...\n")
 * you can set debug_mask value
 * to choose which module need to print
 * if you need to add more modules,
 * please refer to the original way
 */

enum {
    DEBUG_TEST1       = 0,
    DEBUG_TEST2,
    DEBUG_TEST3,
    DEBUG_HELLO,
};

#define DEBUG_DESC_TEST1    "Test1"
#define DEBUG_DESC_TEST2    "Test2"
#define DEBUG_DESC_TEST3    "Test3"
#define DEBUG_DESC_HELLO    "Hello"

#endif /* __LOGGER_RC_H__ */
