#include <stdio.h>
#include "logger_rc.h"
#include "logger.h"
#include "hello.h"


LOG_MOD_DECLARE(TAG, DEBUG_TEST3);

int main(int argc, const char *argv[])
{
    const ModLogDef_t mod_array[] = {
        {DEBUG_TEST1, DEBUG_DESC_TEST1},
        {DEBUG_TEST2, DEBUG_DESC_TEST2},
        {DEBUG_TEST3, DEBUG_DESC_TEST3},
	{DEBUG_HELLO, DEBUG_DESC_HELLO}
    };

    logger_init(mod_array, sizeof(mod_array)/sizeof(ModLogDef_t), NULL);

    logger_level(ELEVEL_TRACE);

    LOGD(DEBUG_TEST1, "call logger_init");
    LOGD(DEBUG_TEST2, "print int    : %d", 100);
    LOGD(DEBUG_TEST3, "print string : %s", "hello world!");
  
    hello_print();

    LOGD(TAG, "logger test success!");
    LOGT(TAG, "yangtongxian!");

    return 0;
}
