#include <stdio.h>
#include "logger.h"
#include "logger_rc.h"

LOG_MOD_DECLARE(TAG, DEBUG_HELLO);

void hello_print()
{
    LOGD(TAG, "logger print : hello word !");

    return 0;
}

