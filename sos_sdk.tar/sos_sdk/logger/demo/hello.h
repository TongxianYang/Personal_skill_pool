#ifndef __HELLO_H__
#define __HELLO_H__
#include "logger.h"
#include "logger_rc.h"

void hello_print();

#endif /* __HELLO_H__ */
