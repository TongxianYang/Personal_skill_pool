#include <stdio.h>
#include <stdarg.h>
#include <sys/time.h>
#include <time.h>
#include "logger.h"

#define LOGGER_BUF_SIZE  1024

#define likely(x)        __builtin_expect(!!(x), 1)
#define unlikely(x)      __builtin_expect(!!(x), 0)

__attribute__((weak)) unsigned int debug_mask = 0x0;
__attribute__((weak)) TLogLevel g_log_level = ELEVEL_DEBUG;

static ModLogDef_t *g_mod_array = NULL;
static FILE *log_fp = NULL;
static char _logger_args_buf[LOGGER_BUF_SIZE];
static const char* _logger_format = "%s.%03ld %s/%s [%s:%d]: %s\n";
static const char* t_level[] = {"T", "D", "I", "E"};

void logger_printf(int mod_id, int level, const char* filename, const char* func, unsigned int line, const char* format, ...)
{
    va_list list;

    struct timeval now;
    struct tm tmBuf;
    struct tm *ptm;
    char timeBuf[32];

    if (unlikely(debug_mask & ((0x1) << mod_id)) && unlikely(level >= g_log_level)) {
        gettimeofday(&now, NULL);
        ptm = localtime_r(&(now.tv_sec), &tmBuf);
        strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%d %H:%M:%S", ptm);
        va_start(list, format);
        vsnprintf(_logger_args_buf, LOGGER_BUF_SIZE, format, list);
        va_end(list);
        ModLogDef_t *modlog = &g_mod_array[mod_id];
        printf(_logger_format,timeBuf,now.tv_usec/1000,t_level[level],modlog->mod_name,func,line,_logger_args_buf);
        if (log_fp) {
            fprintf(log_fp,_logger_format,timeBuf,now.tv_usec/1000,t_level[level],modlog->mod_name,func,line,_logger_args_buf);
            fflush(log_fp);
        }
    }
}

int logger_init(const ModLogDef_t *mod_array, unsigned int mod_num, const char *log_file)
{
    int ret = -1;
    struct timeval now;
    struct tm tmBuf;
    struct tm *ptm;
    char timeBuf[32];

    if (log_file != NULL) {
        log_fp = fopen(log_file, "a");
    }

    gettimeofday(&now, NULL);
    ptm = localtime_r(&(now.tv_sec), &tmBuf);
    strftime(timeBuf, sizeof(timeBuf), "%m-%d %H:%M:%S", ptm);

    //从文件获取log配置
    debug_mask = 0xffffffff;

    g_mod_array = (ModLogDef_t *)malloc(sizeof(ModLogDef_t) * mod_num);
    if (g_mod_array == NULL) {
        printf(_logger_format,timeBuf,now.tv_usec/1000,t_level[ELEVEL_ERROR],"Logger",__FUNCTION__,__LINE__,"malloc fail");
        goto err_exit;
    }

    memcpy(g_mod_array, mod_array, sizeof(ModLogDef_t) * mod_num);

    ret = 0;
    printf(_logger_format,timeBuf,now.tv_usec/1000,t_level[ELEVEL_INFO],"Logger",__FUNCTION__,__LINE__,"logger init ok");
    return 0;

err_exit:
    printf(_logger_format,timeBuf,now.tv_usec/1000,t_level[ELEVEL_ERROR],"Logger",__FUNCTION__,__LINE__,"logger init fail");
    return -1;
}

int logger_level(TLogLevel level)
{
    if (level >= ELEVEL_TRACE && level <= ELEVEL_ERROR)
        g_log_level = level;
    return 0;
}

int logger_module_enable(ModMask_t mod_mask)
{
    debug_mask |= mod_mask;
    return 0;
}

int logger_module_disable(ModMask_t mod_mask)
{
    debug_mask &= ~mod_mask;
    return 0;
}
