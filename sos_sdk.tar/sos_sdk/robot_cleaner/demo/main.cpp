#include <string.h>
#include <pthread.h>
#include <memory>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "logger.h"
#include "logger_rc.h"
#include "robot_controller.h"
#include "device_manager.h"

LOG_MOD_DECLARE(TAG, DEBUG_STATE_MANAGER);

int main(int argc, char **argv)
{
    int rc;
    bool success;

    ModLogDef_t logs[] = {
        {DEBUG_SKELETON_THREAD,     DEBUG_DESC_SKELETON_THREAD},
        {DEBUG_STATE_MACHINE,       DEBUG_DESC_STATE_MACHINE},
        {DEBUG_STATE_MANAGER,       DEBUG_DESC_STATE_MANAGER},
        {DEBUG_ROBOT_CONTROLLER,    DEBUG_DESC_ROBOT_CONTROLLER},
        {DEBUG_DEVICE_MANAGER,      DEBUG_DESC_DEVICE_MANAGER}
    };

    logger_init(logs, sizeof(logs)/sizeof(ModLogDef_t), NULL);
    LOGD(TAG, "transceiver v1.0.1");
    LOGD(TAG, "%s %s", __DATE__, __TIME__);

    std::shared_ptr<DeviceManager> device_manager;
    //std::shared_ptr<TaskManager> task_manager;
    std::shared_ptr<RobotController> robot_controller;
    //std::shared_ptr<ConditionManager> condition_manager;
    //std::shared_ptr<SuspendManager> suspend_manager;
    //std::shared_ptr<LedController> led_controller;
    std::shared_ptr<RobotStateManager> robot_state_manager;
    //std::shared_ptr<ConfigurationManager> configuration_manager;
    //std::shared_ptr<AlarmManager> alarm_manager;
    //std::shared_ptr<ScheduleManager> schedule_manager;

    //setup_exit_handler();

   device_manager = DeviceManager::getInstance();
   //task_manager = std::make_shared<TaskManager>();
   robot_controller = std::make_shared<RobotController>();
   //condition_manager = std::make_shared<ConditionManager>();
   //led_controller = std::make_shared<LedController>();
   robot_state_manager = std::make_shared<RobotStateManager>();
   //configuration_manager = std::make_shared<ConfigurationManager>();
   //alarm_manager = AlarmManager::getInstance();
   //schedule_manager = std::make_shared<ScheduleManager>();

   //led_controller->setDeviceManager(device_manager);
   //robot_controller->setAlarmManager(alarm_manager);
   robot_controller->setRobotStateManger(robot_state_manager);
   //robot_controller->setConfigurationManager(configuration_manager);
   //robot_controller->setTaskManager(task_manager);
   robot_controller->setDeviceManager(device_manager);
   //robot_controller->setConditionManager(condition_manager);
   //robot_controller->setLedController(led_controller);
   //robot_controller->setScheduleManager(schedule_manager);

   //success = alarm_manager->init();
   //if (success == false) {
   //    log_error(TAG, "alarm manager init failed");
   //    return 0;
   //}

   //success = schedule_manager->init();
   //if (success == false) {
   //    log_error(TAG, "schedule manager init failed");
   //    return 0;
   //}

   //success = configuration_manager->init();
   //if (success == false) {
   //    log_error(TAG, "configuration manager init failed");
   //    return 0;
   //}
   success = device_manager->init();
   if (success == false) {
       LOGE(TAG, "device manager init failed");
       return 0;
   }
   //success = condition_manager->init();
   //if (success == false) {
   //    log_error(TAG, "condition manager init failed");
   //    return 0;
   //}
   success = robot_controller->init();
   if (success == false) {
       LOGE(TAG, "device manager init failed");
       return 0;
   }
   //success = led_controller->init();
   //if (success == false) {
   //    log_error(TAG, "led controller init failed");
   //    return 0;
   //}

   //alarm_manager->start();
   //configuration_manager->start();
   //device_manager->start();
   //condition_manager->start();
   //task_manager->start();
   robot_controller->start();
   //led_controller->start();

    while (1)
    {
        usleep(1 * 1000 * 1000);
    }

   //task_manager->stop();
   //device_manager->stop();

    return 0;
}


#if 0
//
// Created by xhome on 2020/9/7.
// 摩尔类型状态机
//

#include <iostream>
#include "tinyfsm.hpp"

//1. 事件的声明,可以携带参数
struct Toggle : tinyfsm::Event{};

//2.定义状态机基类, 投食型状态机
struct Switch : tinyfsm::MooreMachine<Switch>
{
    //纯虚反射，需要在每个状态机中实现.
    virtual void react(Toggle const &) = 0;
};

//3.状态机申明
struct Off;

struct On : Switch{

    void entry() override {
        std::cout << " light ON " << std::endl;
    };

    void react(Toggle const &) override {
        transit<Off>(); //有限状态机状态切换到off
    }
};

struct Off :Switch{
    void entry() override {
        std::cout << " light OFF " << std::endl;
    };
    void react(Toggle const &) override {
        transit<On>();  //状态切换到on
    }
};

//初始化状态机的状态.
FSM_INITIAL_STATE(Switch, Off)

int main()
{
    Switch::start();

    std::cout << "> You are facing a light switch..." << std::endl;
    while(1)
    {
        char c;
        std::cout << std::endl << "t=Toggle, q=Quit ? ";
        std::cin >> c;
        switch(c) {
            case 't':
                std::cout << "> Toggling switch..." << std::endl;
                Switch::dispatch(Toggle());
                break;
            case 'q':
                return 0;
            default:
                std::cout << "> Invalid input" << std::endl;
        };
    }
}
#endif
