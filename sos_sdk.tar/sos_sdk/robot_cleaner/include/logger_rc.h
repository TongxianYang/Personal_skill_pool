#ifndef __LOGGER_RC_H__
#define __LOGGER_RC_H__

/**
 * Unified debug log specification,
 * different modules to print a different label
 * and will print func name and line
 * Instructions, such as airkiss module want add a print
 * LOGE(DEBUG_TEST,"hello workld ...\n")
 * you can set debug_mask value
 * to choose which module need to print
 * if you need to add more modules,
 * please refer to the original way
 */

enum {
    DEBUG_SKELETON_THREAD = 0,
    DEBUG_STATE_MACHINE,
    DEBUG_STATE_MANAGER,
    DEBUG_ROBOT_CONTROLLER,
    DEBUG_DEVICE_MANAGER,
};

#define DEBUG_DESC_SKELETON_THREAD      "SkeletonThread"
#define DEBUG_DESC_STATE_MACHINE        "StateMachine"
#define DEBUG_DESC_STATE_MANAGER        "StateManager"
#define DEBUG_DESC_ROBOT_CONTROLLER     "RobotController"
#define DEBUG_DESC_DEVICE_MANAGER       "DeviceManager"

#endif /* __LOGGER_RC_H__ */
