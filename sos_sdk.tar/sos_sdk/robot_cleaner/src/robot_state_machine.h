#ifndef ROBOT_STATE_MACHINE_H
#define ROBOT_STATE_MACHINE_H

#include <memory>

#include "tinyfsm.hpp"
#include "robot_state_context.h"
//#include <task_manager.h>
//#include <device_manager.h>
//#include <rpc/navigation_client_handler.h>

namespace state_machine {

// ----------------------------------------------------------------------------
// Event declarations
//

struct KeyAction : tinyfsm::Event
{

};

struct Recharge : tinyfsm::Event
{

};

struct RobotWaring : tinyfsm::Event
{

};

struct RobotSafe : tinyfsm::Event
{

};

struct RobotModeNone : tinyfsm::Event
{

};


struct RobotPartitionClean : tinyfsm::Event
{
    int zone_mode;
    //AppCleanZoneData clean_zone_data;
};

struct RobotModeAutoClean : tinyfsm::Event
{

};

struct RobotModeRandom : tinyfsm::Event
{

};

struct RobotModeAlongWall : tinyfsm::Event
{

};

struct RobotCharging : tinyfsm::Event
{

};

struct RobotModeAppAction : tinyfsm::Event
{

};

struct RobotChargingBeMove : tinyfsm::Event
{

};

struct RobotPointClean : tinyfsm::Event
{
    //AppPointCleanData clean_point_data;
};

class RobotStateContext;

class RobotStateMachine : public tinyfsm::Fsm<RobotStateMachine>
{
public:
    RobotStateMachine();

    /* default reaction for unhandled events */
    void react(tinyfsm::Event const &event) { };

    /* non-virtual declaration: reactions are the same for all states */
    void react(KeyAction const &event);
    void react(RobotModeAppAction const &event);
    void react(Recharge const &event);
    void react(RobotModeNone const &event);
    void react(RobotModeAutoClean const &event);
    void react(RobotCharging const &event);
    void react(RobotWaring const &event);
    void react(RobotSafe const &event);
    void react(RobotPartitionClean const &event);
    void react(RobotPointClean const &event);
    void react(RobotChargingBeMove const &event);
    void react(RobotModeAlongWall const &event);
    void react(RobotModeRandom const &event);

    virtual void entry(void) = 0;
    virtual void exit(void) { };

    static void setRobotContext(std::shared_ptr<RobotStateContext> context) {
        RobotStateMachine::context = context;
    }

protected:
    static std::shared_ptr<RobotStateContext> context;
};

}

#endif
