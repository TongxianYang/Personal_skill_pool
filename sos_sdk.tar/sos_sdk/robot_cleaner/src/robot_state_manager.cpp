#include "robot_state_manager.h"
#include "logger.h"
#include "logger_rc.h"

LOG_MOD_DECLARE(TAG, DEBUG_STATE_MANAGER);

RobotStateManager::RobotStateManager():state_(RobotState::kRobotStateClosed)
{

}

int RobotStateManager::getNowState()
{
    return state_;
}

void RobotStateManager::setRobotState(RobotState state)
{
    std::unique_lock<std::mutex> lock(state_lock_);

    state_ = state;

    state_condition_.notify_all();
}

bool RobotStateManager::isStandby()
{
    return state_ == RobotState::kRobotStateStandby;
}

bool RobotStateManager::isRecharge()
{
    return state_ == RobotState::kRobotRecharge;
}

bool RobotStateManager::isWarning()
{
    return state_ == RobotState::kRobotWarning;
}

bool RobotStateManager::isCharging()
{
    return state_ == RobotState::kRobotCharging;
}

bool RobotStateManager::isOutOffTrouble()
{
    return state_ == RobotState::kRobotOutOffTrouble;
}

bool RobotStateManager::isDeepSleep()
{
    return state_ == RobotState::kRobotDeepsleep;
}

bool RobotStateManager::isRunning()
{
    return state_ == RobotState::kRobotRunning;
}

bool RobotStateManager::isKeyStop()
{
    if (state_ != RobotState::kKeyStop){
        return false;
    } else {
        setRobotState(RobotState::kRobotStateStandby);
        LOGD(TAG, "robot state from is key stop change to standby");
        return true;
    }
}

bool RobotStateManager::isFixedPointClean()
{
    return state_ == RobotState::kRobotFixedPointClean;
}

bool RobotStateManager::isFingerPointClean()
{
    return state_ == RobotState::kRobotFingerPointClean;
}

bool RobotStateManager::changerToFixedPointClean()
{
    setRobotState(RobotState::kRobotFixedPointClean);
    return true;
}

bool RobotStateManager::changerToFingerPointClean()
{
    setRobotState(RobotState::kRobotFingerPointClean);
    return true;
}

bool RobotStateManager::changeToRuning()
{
    setRobotState(RobotState::kRobotRunning);
    return true;
}

bool RobotStateManager::changerToWarning()
{
    setRobotState(RobotState::kRobotWarning);
    return true;
}

bool RobotStateManager::changetToStandby()
{
    setRobotState(RobotState::kRobotStateStandby);
    return true;
}

bool RobotStateManager::changerToCharging()
{
    setRobotState(RobotState::kRobotCharging);
    return true;
}

bool RobotStateManager::changerToKeyStop()
{
    setRobotState(RobotState::kKeyStop);
    return true;
}

bool RobotStateManager::changetToRecharge()
{
    setRobotState(RobotState::kRobotRecharge);
    return true;
}
