#include "robot_state_machine.h"

//#include "task_along_wall.h"
//#include "task_random_clean.h"
//#include "task_auto_clean.h"
//#include "task_recharge.h"
//#include "task_left_charger.h"
//#include "task_partition_zone_clean.h"
//#include "task_point_clean.h"
#include "logger.h"
#include "logger_rc.h"

/*
    DFA it can rebuild it. it base on event and state to changer next state.
*/

LOG_MOD_DECLARE(TAG, DEBUG_STATE_MACHINE);

namespace state_machine {

// ----------------------------------------------------------------------------
// Robot states
//

class RobotStateIdle : public RobotStateMachine
{
    void entry() override {
        LOGI(TAG, "robot enter idle state");
        //context->robot_state_manager->changetToStandby();
        //context->device_manager->syncChassisMode_Standby();
    };

    void exit() override {
        LOGI(TAG, "robot exit idle state");
    };
};

class RobotStateSleep : public RobotStateMachine
{
    void entry() override {
        LOGI(TAG, "robot enter sleep state");
    };

    void exit() override {
        LOGI(TAG, "robot exit sleep state");
    };
};

class RobotStateRunningAutoClean : public RobotStateMachine
{
    void entry() override {
        LOGI(TAG, "robot enter auto clean running state");
        //task_ = std::make_shared<TaskAutoClean>();
        //task_->setRobotStateContext(context);
        //context->task_manager->addTask(task_);
        context->robot_state_manager->changeToRuning();
        //context->device_manager->syncChassisMode_Runing();
    };

    void exit() override {
        LOGI(TAG, "robot exit auto clean running state");
        //if (task_->isRunning()) {
        //    LOGI(TAG, "auto clean task still running");
        //    task_->stop();
        //} else{
        //    LOGE(TAG,"auto clean task is not running, task state %d.", task_->getState());
        //}
    };

private:
    //std::shared_ptr<TaskAutoClean> task_;
};

class RobotStateRunningRandom : public RobotStateMachine
{
    void entry() override {
        LOGI(TAG, "robot enter random running state");
        //task_ = std::make_shared<TaskRandomClean>();
        //task_->setRobotStateContext(context);
        //context->task_manager->addTask(task_);
        context->robot_state_manager->changeToRuning();
        //context->device_manager->syncChassisMode_Runing();
    };

    void exit() override {
        LOGI(TAG, "robot exit random running state");
        //if (task_->isRunning()) {
        //    LOGI(TAG, "random task still running");
        //    task_->stop();
        //} else{
        //    LOGE(TAG,"random task is not running, task state %d.",task_->getState());
        //}
    };

private:
    //std::shared_ptr<TaskRandomClean> task_;
};

class RobotStateRunningAlongWall : public RobotStateMachine
{
    void entry() override {
        LOGI(TAG, "robot enter auto clean running state");
        //task_ = std::make_shared<TaskAlongWall>();
        //task_->setRobotStateContext(context);
        //context->task_manager->addTask(task_);
        context->robot_state_manager->changeToRuning();
        //context->device_manager->syncChassisMode_AlongWall();
    };

    void exit() override {
        LOGI(TAG, "robot exit auto clean running state");
        //if (task_->isRunning()) {
        //    LOGI(TAG, "along wall task still running");
        //    task_->stop();
        //} else{
        //    LOGE(TAG,"along wall task is not running, task state %d.",task_->getState());
        //}
    };

private:
    //std::shared_ptr<TaskAlongWall> task_;
};

class RobotStateRunningPartitionClean : public RobotStateMachine
{
    void entry() override {
        LOGI(TAG, "robot enter partition clean running state");
        //task_ = std::make_shared<TaskPartitionZoneClean>();
        //task_->setRobotStateContext(context);
        //context->task_manager->addTask(task_);
        context->robot_state_manager->changeToRuning();
        //context->device_manager->syncChassisMode_Runing();
    };

    void exit() override {
        LOGI(TAG, "robot exit partition clean running state");
        //if (task_->isRunning()) {
        //    LOGI(TAG, "partition clean task still running");
        //    task_->stop();
        //}else{
        //    LOGE(TAG,"partition clean task is not running");
        //}
    };

private:
    //std::shared_ptr<TaskPartitionZoneClean> task_;
};

class RobotStateRecharge : public RobotStateMachine
{
    void entry() override {
        LOGI(TAG, "robot enter recharge state");
        //task_ = std::make_shared<TaskRecharge>();
        //task_->setRobotStateContext(context);
        //context->task_manager->addTask(task_);
        context->robot_state_manager->changetToRecharge();
    };

    void exit() override {
        LOGI(TAG, "robot exit recharge state");
        //if (task_->isRunning()) {
        //    LOGI(TAG, "recharge task still running");
        //    task_->stop();
        //}else{
        //    LOGE(TAG,"recharge task is not running");
        //}
    };

private:
    //std::shared_ptr<TaskRecharge> task_;
};

class RobotStateWaring : public RobotStateMachine
{
    void entry() override {
        //context->device_manager->disabledCleningDevice();
        LOGI(TAG, "robot enter the warning mode");
        context->robot_state_manager->changerToWarning();
    };

    void exit() override {
        LOGI(TAG, "robot exit the warning mode");
    };

private:

};

class RobotModeRuningLeftCharger : public RobotStateMachine
{
    void entry() override {
        LOGI(TAG, "robot is lefting the charger");
        //task_ = std::make_shared<TaskLeftCharger>();
        //task_->setRobotStateContext(context);
        //context->task_manager->addTask(task_);
        //context->device_manager->syncChassisMode_Runing();
    };

    void exit() override {
        LOGI(TAG, "robot exit left charger state");
        //if (task_->isRunning()) {
        //    LOGI(TAG, "left charger task still running");
        //    task_->stop();
        //}else{
        //    LOGE(TAG,"left charger task is not running");
        //}
    };

private:
    //std::shared_ptr<TaskLeftCharger> task_;
};

class RobotModeRuningPointClean : public RobotStateMachine
{
    void entry() override {
        LOGI(TAG, "robot is runing point Clean");
        //task_ = std::make_shared<TaskPointClean>();
        //task_->setRobotStateContext(context);
        //context->task_manager->addTask(task_);
        //context->device_manager->syncChassisMode_Runing();
    };

    void exit() override {
        LOGI(TAG, "robot exit point clean state");
        //if (task_->isRunning()) {
        //    LOGI(TAG, "point clean task still running");
        //    task_->stop();
        //} else{
        //    LOGE(TAG,"point clean task is not running");
        //}
    };

private:
    //std::shared_ptr<TaskPointClean> task_;
};

class RobotStateCharging : public RobotStateMachine
{
    void entry() override {
        LOGI(TAG, "robot is charging");
        //context->device_manager->disabledCleningDevice();
        context->robot_state_manager->changerToCharging();
        //context->app_handler->machineStateUpload_Charging();
        //context->slam_handler->sendIsDock();
    };

    void exit() override {
        LOGI(TAG, "robot exit charging state");
    };

private:
};


RobotStateMachine::RobotStateMachine()
{

}

void RobotStateMachine::react(RobotModeAppAction const &event)
{
    //robot is warning;
    if(is_in_state<RobotStateWaring>()){
        LOGI(TAG, "robot is warning");
        return;
    }

    if(is_in_state<RobotStateRunningAutoClean>() && context->robot_state_manager->isRunning()){
        LOGE(TAG, "bad task ");
        return;
    }

    //left the recharge 
    if(is_in_state<RobotStateCharging>()){
        transit<RobotModeRuningLeftCharger>();
        return;
    } else if (is_in_state<RobotModeRuningLeftCharger>()){
        LOGI(TAG, "robot is lefting the charging, get key command ,so change to ide state");
        context->robot_state_manager->changerToKeyStop();
        transit<RobotStateIdle>();
        return;
    }

    //stop else mode
    if (!is_in_state<RobotStateIdle>() && !is_in_state<RobotStateRunningAutoClean>) {
        transit<RobotStateIdle>();
    } 

    //auto clean mode start and stop;
    if (is_in_state<RobotStateIdle>()) {
        transit<RobotStateRunningAutoClean>();
    } else {
        transit<RobotStateIdle>();
    }

}


void RobotStateMachine::react(KeyAction const &event)
{
    //robot is warning;
    if(is_in_state<RobotStateWaring>()){
        LOGI(TAG, "robot is warning");
        return;
    }

    //left the recharge 
    if(is_in_state<RobotStateCharging>()){
        transit<RobotModeRuningLeftCharger>();
        return;
    } else if (is_in_state<RobotModeRuningLeftCharger>()){
        LOGI(TAG, "robot is lefting the charging, get key command ,so change to ide state");
        context->robot_state_manager->changerToKeyStop();
        transit<RobotStateIdle>();
        return;
    }

    //stop else mode
    if (!is_in_state<RobotStateIdle>() && !is_in_state<RobotStateRunningAutoClean>) {
        transit<RobotStateIdle>();
    } 

    //auto clean mode start and stop;
    if (is_in_state<RobotStateIdle>()) {
        transit<RobotStateRunningAutoClean>();
    } else {
        transit<RobotStateIdle>();
    }
}

void RobotStateMachine::react(RobotPartitionClean const &event)
{
    //robot is warning;
    if(is_in_state<RobotStateWaring>()){
        LOGI(TAG, "robot is warning");
        return;
    }

    if(is_in_state<RobotStateRunningPartitionClean>() && context->robot_state_manager->isRunning()){
        LOGE(TAG, "bad tast PartitionClean");
        return;
    }

    //left the recharge 
    if(is_in_state<RobotStateCharging>()){
        transit<RobotModeRuningLeftCharger>();
        return;
    } else if (is_in_state<RobotModeRuningLeftCharger>()){
        LOGI(TAG, "robot is lefting the charging, get key command ,so change to ide state");
        context->robot_state_manager->changerToKeyStop();
        transit<RobotStateIdle>();
        return;
    }

    //stop else mode
    if (!is_in_state<RobotStateIdle>() && !is_in_state<RobotStateRunningPartitionClean>) {
        transit<RobotStateIdle>();
    } 

    //partition clean mode start and stop;
    if (is_in_state<RobotStateIdle>()) {     
        transit<RobotStateRunningPartitionClean>(); 
    } else {
        transit<RobotStateIdle>();
    }
}

void RobotStateMachine::react(RobotPointClean const &event)
{
    //robot is warning;
    if(is_in_state<RobotStateWaring>()){
        LOGI(TAG, "robot is warning");
        return;
    }

    //left the recharge 
    if(is_in_state<RobotStateCharging>()){
        transit<RobotModeRuningLeftCharger>();
        return;
    } else if (is_in_state<RobotModeRuningLeftCharger>()){
        LOGI(TAG, "robot is lefting the charging, get key command ,so change to ide state");
        context->robot_state_manager->changerToKeyStop();
        transit<RobotStateIdle>();
        return;
    }

    //stop else mode
    if (!is_in_state<RobotStateIdle>() && !is_in_state<RobotModeRuningPointClean>) {
        transit<RobotStateIdle>();
    } 

    //auto clean mode start and stop;
    if (is_in_state<RobotStateIdle>()) {     
        transit<RobotModeRuningPointClean>(); 
    } else {
        transit<RobotStateIdle>();
    }
}

void RobotStateMachine::react(RobotCharging const &event)
{
    if (is_in_state<RobotStateCharging>()) {
        return;
    } else {
        transit<RobotStateCharging>();
    }
}

void RobotStateMachine::react(RobotChargingBeMove const &event)
{
    if (is_in_state<RobotModeRuningLeftCharger>()){
        return;
    }
    if (is_in_state<RobotStateCharging>()){
        LOGI(TAG, "robot is charging ,but it has been move");
        //context->app_handler->machineStateUpload_StandBy();
        transit<RobotStateIdle>();
    }
}

void RobotStateMachine::react(Recharge const &event)
{
    if(is_in_state<RobotStateWaring>()){
        LOGI(TAG, "robot is warning");
        return;
    }

    //robot when it will on charger 
    if(is_in_state<RobotStateCharging>()){
        LOGI(TAG, "robot is charging");
        return;
    }

    if (is_in_state<RobotStateRecharge>()) {
        transit<RobotStateIdle>();
    } else {
        transit<RobotStateRecharge>();
    }

}

void RobotStateMachine::react(RobotWaring const &event)
{
    if (is_in_state<RobotStateWaring>()){
       return;
    } else {
        transit<RobotStateWaring>();
    }
}

void RobotStateMachine::react(RobotModeNone const &event)
{
    if(is_in_state<RobotStateWaring>()){
        LOGI(TAG, "robot is warning");
        return;
    }

    if (is_in_state<RobotModeRuningLeftCharger>()){
        LOGI(TAG, "robot need to stop left charging");
        context->robot_state_manager->changerToKeyStop();
        transit<RobotStateIdle>();
        return;
    }

    if (is_in_state<RobotStateIdle>()){
        return;
    }
    transit<RobotStateIdle>();
}

void RobotStateMachine::react(RobotModeAutoClean const &event)
{
    if (is_in_state<RobotStateRunningAutoClean>()){
        transit<RobotStateIdle>();
    }else {
        transit<RobotStateRunningAutoClean>();
    }
}

void RobotStateMachine::react(RobotSafe const &event)
{
    if (is_in_state<RobotStateWaring>()){
        transit<RobotStateIdle>();
    }
}

void RobotStateMachine::react(RobotModeAlongWall const &event)
{
    if(is_in_state<RobotStateWaring>()){
        LOGI(TAG, "robot is warning");
        return;
    }

    if(is_in_state<RobotStateRunningAlongWall>() && context->robot_state_manager->isRunning()){
        LOGE(TAG, "bad task");
        return;
    }

    //left the recharge 
    if(is_in_state<RobotStateCharging>()){
        transit<RobotModeRuningLeftCharger>();
        return;
    } else if (is_in_state<RobotModeRuningLeftCharger>()){
        LOGI(TAG, "robot is lefting the charging, get key command ,so change to ide state");
        context->robot_state_manager->changerToKeyStop();
        transit<RobotStateIdle>();
        return;
    }

    //stop else mode
    if (!is_in_state<RobotStateIdle>() && !is_in_state<RobotStateRunningAlongWall>) {
        transit<RobotStateIdle>();
    } 

    //auto clean mode start and stop;
    if (is_in_state<RobotStateIdle>()) {
        transit<RobotStateRunningAlongWall>();
    } else {
        transit<RobotStateIdle>();
    }
}

void RobotStateMachine::react(RobotModeRandom const &event)
{
    if(is_in_state<RobotStateWaring>()){
        LOGI(TAG, "robot is warning");
        return;
    }

    //left the recharge 
    if(is_in_state<RobotStateCharging>()){
        transit<RobotModeRuningLeftCharger>();
        return;
    } else if (is_in_state<RobotModeRuningLeftCharger>()){
        LOGI(TAG, "robot is lefting the charging, get key command ,so change to ide state");
        context->robot_state_manager->changerToKeyStop();
        transit<RobotStateIdle>();
        return;
    }

    //stop else mode
    if (!is_in_state<RobotStateIdle>() && !is_in_state<RobotStateRunningRandom>) {
        transit<RobotStateIdle>();
    } 

    //auto clean mode start and stop;
    if (is_in_state<RobotStateIdle>()) {
        transit<RobotStateRunningRandom>();
    } else {
        transit<RobotStateIdle>();
    }
}

// static define
std::shared_ptr<RobotStateContext> RobotStateMachine::context;

}

// ----------------------------------------------------------------------------
// Initial state definition
//
FSM_INITIAL_STATE(state_machine::RobotStateMachine, state_machine::RobotStateIdle);
