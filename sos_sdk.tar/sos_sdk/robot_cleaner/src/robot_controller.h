#ifndef ROBOT_CONTROLLER_H
#define ROBOT_CONTROLLER_H

#include <mutex>
#include <memory>
#include <condition_variable>

#include "skeleton_thread.h"
#include "queue.h"
#include "event.h"
//#include <task_manager.h>
#include "device_manager.h"
//#include <condition_manager.h>
//#include <configuration_manager.hpp>
//#include <led_controller.h>
#include <robot_state_manager.h>
//#include <alarm_manager.h>
//#include <core/skeleton_thread.h>
//#include <rpc/navigation_rpc_client.h>
//#include <rpc/navigation_client_handler.h>
//#include <rpc/slam_rpc_client.h>
//#include <rpc/slam_handler.h>
//#include <rpc/app_handler.h>
//#include <rpc/app_rpc_client.h>
//#include <schedule_manager.h>

class RobotController : public SkeletonThread
{
public:
    RobotController();

    //void setTaskManager(std::shared_ptr<TaskManager> task_manager);
    void setDeviceManager(std::shared_ptr<DeviceManager> device_manager);
    //void setConditionManager(std::shared_ptr<ConditionManager> condition_manager);
    //void setLedController(std::shared_ptr<LedController> led_controller);
    void setRobotStateManger(std::shared_ptr<RobotStateManager> robot_state_manager);
    //void setConfigurationManager(std::shared_ptr<ConfigurationManager> configuration_manager);
    //void setAlarmManager(std::shared_ptr<AlarmManager> alarm_manager);
    //void setScheduleManager(std::shared_ptr<ScheduleManager> schedule_manager);

    bool init();

protected:
    virtual void onStart();
    virtual bool threadLoop();

    void deviceEventCallback(std::shared_ptr<event::Event> event);
    void alarmEventCallback(std::shared_ptr<event::Event> event);
    void appEventCallback(std::shared_ptr<event::Event> event);
    void navigationCallback(std::shared_ptr<event::Event> event);
    void slamCallback(std::shared_ptr<event::Event> event);
    void scheduleEventCallback(std::shared_ptr<event::Event> event);

    void handleEvent(std::shared_ptr<event::Event> event);
    void handleKeyEvent(std::shared_ptr<event::Event> event);
    void handleRobotModeEvent(std::shared_ptr<event::Event> event);
    void handleSideBrushConditionEvent(std::shared_ptr<event::Event> event);
    void handleGroundCheckConditionEvent(std::shared_ptr<event::Event> event);
    void handleRemoteControlEvent(std::shared_ptr<event::Event> event);
    void handleGamepadEvent(std::shared_ptr<event::Event> event);
    void handleBatteryEvent(std::shared_ptr<event::Event> event);
    void handleGetRobotInfoEvent(std::shared_ptr<event::Event> event);
    void handleAppDeviceData(std::shared_ptr<event::Event> event);
    void handleNetWorkStateEvent(std::shared_ptr<event::Event> event);
    void handleWheelConditionEvent(std::shared_ptr<event::Event> event);
    void handleNavigationEvent(std::shared_ptr<event::Event> event);
    void handleSlamEvent(std::shared_ptr<event::Event> event);
    void handleAlarmMangerEvent(std::shared_ptr<event::Event> event);
    void handleAppointmentsEvent(std::shared_ptr<event::Event> event);

private:
    //std::shared_ptr<TaskManager> task_manager_;
    std::shared_ptr<DeviceManager> device_manager_;
    //std::shared_ptr<ConditionManager> condition_manager_;
    //std::shared_ptr<LedController> led_controller_;
    std::shared_ptr<RobotStateManager> robot_state_manager_;
    //std::shared_ptr<ConfigurationManager> configuration_manager_;
    //std::shared_ptr<AlarmManager> alarm_manager_;
    //std::shared_ptr<ScheduleManager> schedule_manager_;


    core::Queue<std::shared_ptr<event::Event>> event_queue_;
    std::condition_variable event_condition_;
    std::mutex event_mutex_;
    //std::shared_ptr<NavigationRpcClient> navigation_client_;
    //std::shared_ptr<NavigationClientHandler> navigation_handler_;
    //std::shared_ptr<SlamRpcClient> slam_client_;
    //std::shared_ptr<SlamHandler> slam_handler_;
    //std::shared_ptr<AppRpcClient> app_client_;
    //std::shared_ptr<AppHandler> app_handler_;

    //int alarm_id_;
};
extern bool g_charge_flag;
#endif
