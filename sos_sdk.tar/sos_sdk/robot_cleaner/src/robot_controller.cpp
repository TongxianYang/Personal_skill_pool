#include <typeinfo>
#include <functional>

#include "state_machine.h"
#include "robot_state_machine.h"
#include "robot_state_manager.h"
#include "robot_state_context.h"
#include "robot_controller.h"

#include "key.h"
#include "remotecontrol.h"
#include "battery.h"
#include "app_command.h"
#include "app_device_data.h"
#include "appointment.h"
#include "robot_mode.h"
#include "navigation.h"
#include "condition.h"
#include "alarm.h"
#include "slam.h"
#include "net_work_state.h"

#include "logger.h"
#include "logger_rc.h"

LOG_MOD_DECLARE(TAG, DEBUG_ROBOT_CONTROLLER);

bool g_charge_flag;

/*
    ! need rebuild file  led controller. use the robot state_machine and event to controll the led light. 
*/

const int NetWorkCountTime = 2;


RobotController::RobotController()
{

}

// void RobotController::setTaskManager(std::shared_ptr<TaskManager> task_manager)
// {
//     task_manager_ = task_manager;
// }

void RobotController::setDeviceManager(std::shared_ptr<DeviceManager> device_manager)
{
    device_manager_  = device_manager;
}

// void RobotController::setConditionManager(std::shared_ptr<ConditionManager> condition_manager)
// {
//     condition_manager_ = condition_manager;
// }

// void RobotController::setLedController(std::shared_ptr<LedController> led_controller)
// {
//     led_controller_ = led_controller;
// }

// void RobotController::setConfigurationManager(std::shared_ptr<ConfigurationManager> configuration_manager)
// {
//     configuration_manager_ = configuration_manager;
// }

// void RobotController::setAlarmManager(std::shared_ptr<AlarmManager> alarm_manager)
// {
//     alarm_manager_ = alarm_manager;
// }

// void RobotController::setScheduleManager(std::shared_ptr<ScheduleManager> schedule_manager)
// {
//     schedule_manager_ = schedule_manager;
// }


void RobotController::setRobotStateManger(std::shared_ptr<RobotStateManager> robot_state_manager)
{
    robot_state_manager_ = robot_state_manager;
}

bool RobotController::init()
{
    //if (device_manager_ == nullptr || task_manager_ == nullptr || led_controller_ == nullptr) {
    //    return false;
    //}

    //g_charge_flag = false;
    //alarm_id_ = alarm_manager_->allocUserId();

    //alarm_manager_->registerEventCallbacks(std::bind(&RobotController::alarmEventCallback,this,std::placeholders::_1));
    //device_manager_->setEventReportCallback(std::bind(&RobotController::deviceEventCallback, this, std::placeholders::_1));
    //condition_manager_->setEventReportCallback(std::bind(&RobotController::deviceEventCallback, this, std::placeholders::_1));
    //schedule_manager_->setEventReportCallback(std::bind(&RobotController::scheduleEventCallback, this, std::placeholders::_1));
    return true;
}

void RobotController::onStart()
{
    bool success;

    //navigation_client_ = std::make_shared<NavigationRpcClient>();
    //navigation_handler_ = std::make_shared<NavigationClientHandler>();
    //slam_client_ = std::make_shared<SlamRpcClient>();
    //slam_handler_ = std::make_shared<SlamHandler>();
    //app_client_ = std::make_shared<AppRpcClient>();
    //app_handler_ = std::make_shared<AppHandler>();

    //app_handler_->registerEventCallback(std::bind(&RobotController::appEventCallback, this, std::placeholders::_1));
    //navigation_handler_->registerRobotCleanCallback(std::bind(&RobotController::navigationCallback, this, std::placeholders::_1));
    //slam_handler_->registerRobotCleanCallback(std::bind(&RobotController::slamCallback, this, std::placeholders::_1));

    //std::string server_address = "/tmp/navigation_socket";
    //navigation_client_->setServerAddress(server_address);
    //navigation_client_->setRpcHandler(navigation_handler_);

    //std::string slam_server_address = "/tmp/slam_socket";
    //slam_client_->setServerAddress(slam_server_address);
    //slam_client_->setRpcHandler(slam_handler_);

    //std::string app_server_address = "/tmp/app_socket";
    //app_client_->setServerAddress(app_server_address);
    //app_client_->setRpcHandler(app_handler_);

    //navigation_handler_->start();
    //success = navigation_client_->connect();
    //if (success == false) {
    //    log_error(TAG, "connect to navigation server failed");
    //}

    //slam_handler_->start();
    //success = slam_client_->connect();
    //if (success == false) {
    //    log_error(TAG, " connect to slam server failed");
    //}

    //app_handler_->start();
    //success = app_client_->connect();
    //if (success == false) {
    //    log_error(TAG, " connect to app server failed");
    //}

    auto context = std::make_shared<state_machine::RobotStateContext>();
    //context->task_manager = task_manager_;
    //context->device_manager = device_manager_;
    //context->navigation_handler = navigation_handler_;
    //context->slam_handler = slam_handler_;
    //context->app_handler = app_handler_;
    context->robot_state_manager = robot_state_manager_;
    //context->configuration_manager = configuration_manager_;

    state_machine::RobotStateMachine::setRobotContext(context);
    //led_controller_->setContext(context);

    state_machine::fsm_list::start();

    //init part
    //app_handler_->responseDeviceData(AppFanTapPotionStandard,AppTankLevelLow);
    //app_handler_->machineStateUpload_StandBy();

    //device_manager_->syncChassisMode_Standby();
}

void RobotController::appEventCallback(std::shared_ptr<event::Event> event)
{
    bool success;
    std::unique_lock<std::mutex> lck(event_mutex_);

    success = event_queue_.enqueue(event);
    if (success == false) {
        LOGE(TAG, "enqueue app event failed");
        return;
    }

    event_condition_.notify_all();
}

void RobotController::navigationCallback(std::shared_ptr<event::Event> event)
{
    bool success;
    std::unique_lock<std::mutex> lck(event_mutex_);

    success = event_queue_.enqueue(event);
    if (success == false) {
        LOGE(TAG, "enqueue app event failed");
        return;
    }

    event_condition_.notify_all();
}

void RobotController::slamCallback(std::shared_ptr<event::Event> event)
{
    bool success;
    std::unique_lock<std::mutex> lck(event_mutex_);

    success = event_queue_.enqueue(event);
    if (success == false) {
        LOGE(TAG, "enqueue app event failed");
        return;
    }

    event_condition_.notify_all();
}

void RobotController::alarmEventCallback(std::shared_ptr<event::Event> event)
{
    bool success;
    std::unique_lock<std::mutex> lck(event_mutex_);

    success = event_queue_.enqueue(event);
    if (success == false) {
        LOGE(TAG, "enqueue alarm event failed");
        return;
    }

    event_condition_.notify_all();
}

void RobotController::scheduleEventCallback(std::shared_ptr<event::Event> event)
{
    bool success;
    std::unique_lock<std::mutex> lck(event_mutex_);

    success = event_queue_.enqueue(event);
    if (success == false) {
        LOGE(TAG, "enqueue schedule event failed");
        return;
    }

    event_condition_.notify_all();
}

void RobotController::deviceEventCallback(std::shared_ptr<event::Event> event)
{
    bool success;
    std::unique_lock<std::mutex> lck(event_mutex_);

    success = event_queue_.enqueue(event);
    if (success == false) {
        LOGE(TAG, "enqueue device event failed");
        return;
    }

    event_condition_.notify_all();
}

bool RobotController::threadLoop()
{
    bool success;
    bool got_event;
    std::shared_ptr<event::Event> event;

    std::unique_lock<std::mutex> lock(event_mutex_);
    got_event = event_condition_.wait_for(lock, std::chrono::milliseconds(100),  [&] {
        return event_queue_.size() != 0;
    });

    if (got_event == false) {
        return true;
    }

    success = event_queue_.dequeue(event);
    if (success == false) {
        LOGD(TAG, "got event from event queue failed");
        return true;
    }

    handleEvent(event);

    //led_controller_->setEvent(event);

    return true;
}

void RobotController::handleEvent(std::shared_ptr<event::Event> event)
{
    const std::type_info& event_type = typeid(*event);

    // if (event_type == typeid(event::Key)) {
    //     handleKeyEvent(event);
    // } else if (event_type == typeid(event::RobotMode)) {
    //     handleRobotModeEvent(event);
    // } else if (event_type == typeid(event::SideBrushCondition)) {
    //     handleSideBrushConditionEvent(event);
    // } else if (event_type == typeid(event::GroundCheckerCondition) && (robot_state_manager_->isCharging() != true)){
    //     handleGroundCheckConditionEvent(event);
    // } else if (event_type == typeid(event::RemoteControl)){
    //     handleRemoteControlEvent(event);
    // } else if (event_type == typeid(event::Gamepad)){
    //     handleGamepadEvent(event);
    // } else if (event_type == typeid(event::Battery)){
    //     handleBatteryEvent(event);
    // } else if (event_type == typeid(event::GetRobotInfoEvent)) {
        
    // } else if (event_type == typeid(event::NetWorkState)){
    //     handleNetWorkStateEvent(event);
    // } else if (event_type == typeid(event::WheelCondition)){
    //     handleWheelConditionEvent(event);
    // } else if (event_type == typeid(event::Navigation)){
    //     handleNavigationEvent(event);
    // } else if (event_type == typeid(event::Slam)){
    //     handleSlamEvent(event);
    // } else if (event_type == typeid(event::AppDeviceDataEvent)){
    //     handleAppDeviceData(event);
    // } else if (event_type == typeid(event::Alarm)){
    //     handleAlarmMangerEvent(event);
    // } else if (event_type == typeid(event::Appointment)){
    //     handleAppointmentsEvent(event);
    // }
    // else {
    //     LOGD(TAG, "unhandle event type %s", event_type.name());
    // }
}

void RobotController::handleKeyEvent(std::shared_ptr<event::Event> event)
{
    std::shared_ptr<event::Key> key_event = std::dynamic_pointer_cast<event::Key>(event);
    bool success = false;
    int charge_mode;

    switch (key_event->code_)
    {
    case event::Key::kKeyCodeAction:
        state_machine::KeyAction action;
        state_machine::send_event(action);
        break;

    case event::Key::kKeyCodeWifi:
        /* this path needs to be moved and changer state machine.*/
        //success = app_handler_->connectNetWork();
        //alarm_manager_->setCountDown(NetWorkCountTime);
        if (success == false){
            LOGE(TAG, "send connect network command fail");
        } else{
            LOGI(TAG, "send connect network command success");
        }
        break;

    case event::Key::kKeyCodeHome:
        state_machine::Recharge recharge;
        state_machine::send_event(recharge);
        charge_mode = 1; //EXTERNAL_CMD_CHARGE;
        //success = navigation_handler_->charge(charge_mode);
        if (success == false){
            LOGE(TAG, "send charge mode[%d] to navigation fail\n", charge_mode);
        } else{
            LOGI(TAG, "send charge mode[%d] to navigation success\n", charge_mode);
        }
        break;

    case event::Key::kKeyCodeFixPoint:
        // state_machine::RobotModeAutoClean action;
        // state_machine::send_event(action);
        break;

    default:
        break;
    }
}

void RobotController::handleGamepadEvent(std::shared_ptr<event::Event> event)
{
    std::shared_ptr<event::Gamepad> gamepad_event = std::dynamic_pointer_cast<event::Gamepad>(event);
    bool success = false;

    if (robot_state_manager_->isWarning()){
        LOGE(TAG, "robot is warning, it can not use the remotecontroll");
        return;
    }

    switch (gamepad_event->code_)
    {
    case event::Gamepad::kAppGamePadNone:
        //success = navigation_handler_->gamepadCommand(GAMEPAD_IDLE);
        if (success == false){
            LOGE(TAG, "send gamepad command none fail");
        } else{
            LOGI(TAG, "send gamepad command none success");
        }
        break;

    case event::Gamepad::kAppGamePadGo:
        //success = navigation_handler_->gamepadCommand(GAMEPAD_GO);
        if (success == false){
            LOGE(TAG, "send gamepad command go fail");
        } else{
            LOGI(TAG, "send gamepad command go success");
        }
        break;

    case event::Gamepad::kAppGamePadTurnLeft:
        //success = navigation_handler_->gamepadCommand(GAMEPAD_TURN_LEFT);
        if (success == false){
            LOGE(TAG, "send gamepad command left fail");
        } else{
            LOGI(TAG, "send gamepad command left success");
        }
        break;

    case event::Gamepad::kAppGamePadTurnRight:
        //success = navigation_handler_->gamepadCommand(GAMEPAD_TURN_RIGHT);
        if (success == false){
            LOGE(TAG, "send gamepad command right fail");
        } else{
            LOGI(TAG, "send gamepad command right success");
        }
        break;

    case event::Gamepad::kAppGamePadTurnBack:
        //success = navigation_handler_->gamepadCommand(GAMEPAD_TURN_BACK);
        if (success == false){
            LOGE(TAG, "send gamepad command turn back fail");
        } else{
            LOGI(TAG, "send gamepad command turn back success");
        }
        break;
    }
}

void RobotController::handleBatteryEvent(std::shared_ptr<event::Event> event)
{
    std::shared_ptr<event::Battery> battery_event = std::dynamic_pointer_cast<event::Battery>(event);
    bool success = false;
    int charge_mode;

    switch (battery_event->event_)
    {
    case event::Battery::kBatteryValueUpdate:
        //app_handler_->batteryUpload(battery_event->batteryValue_);
        break;

    case event::Battery::kLowPowerLevelOne:
        if(robot_state_manager_->isCharging()){
            LOGI(TAG, "robot lowpower charging");
            return;
        }
        charge_mode = 0; //LOW_POWER_CHARGE;
        //success = navigation_handler_->charge(charge_mode);
        if (success == false) {
            LOGE(TAG, "send charge mode[%d] to navigation fail", charge_mode);
        } else{
            LOGI(TAG, "send charge mode[%d] to navigation success", charge_mode);
        }
        break;

    default:
        break;
    }
}

void RobotController::handleNetWorkStateEvent(std::shared_ptr<event::Event> event)
{

}

void RobotController::handleGetRobotInfoEvent(std::shared_ptr<event::Event> event)
{
    //struct AppRobotInfo robot_info;
    auto get_event = std::dynamic_pointer_cast<event::GetRobotInfoEvent>(event);

    //app_handler_->sendRobotInfo(robot_info);
}

void RobotController::handleAppDeviceData(std::shared_ptr<event::Event> event)
{
    auto device_data = std::dynamic_pointer_cast<event::AppDeviceDataEvent>(event);

    if (robot_state_manager_->isWarning()){
        LOGI(TAG, "robot is warning, it can not set the device");
        return;
    }

    switch (device_data->event_type)
    {
        case event::AppDeviceDataEvent::Fan :
        {
            //app_handler_->responseDeviceData(device_data->level,-1);
            if (robot_state_manager_->isStandby() || robot_state_manager_->isCharging()){
                LOGI(TAG,"robot is standby.can not enabled the fan");
                switch(device_data->level)
                {
                    case event::AppDeviceDataEvent::AppFanTapPotionStandard:
                        //device_manager_->getFan()->setLevelConfig(kDeviceFanTapPotionStandard);
                        break;
                    case event::AppDeviceDataEvent::AppFanTapPotionQuietly:
                        //device_manager_->getFan()->setLevelConfig(kDeviceFanTapPotionQuietly);
                        break;
                    case event::AppDeviceDataEvent::AppFanTapPotionLow:
                        //device_manager_->getFan()->setLevelConfig(kDeviceFanTapPotionLow);
                        break;
                    case event::AppDeviceDataEvent::AppFanTapPotionPowerful:
                        //device_manager_->getFan()->setLevelConfig(kDeviceFanTapPotionPowerful);
                        break;
                    case event::AppDeviceDataEvent::AppFanTapPotionMax:
                        //device_manager_->getFan()->setLevelConfig(kDeviceFanTapPotionMax);
                        break;
                    default:
                        break;
                }
                return;
            }

            switch(device_data->level)
            {
                case event::AppDeviceDataEvent::AppFanTapPotionStandard:
                    //device_manager_->getFan()->enabled(kDeviceFanTapPotionStandard);
                    break;
                case event::AppDeviceDataEvent::AppFanTapPotionQuietly:
                    //device_manager_->getFan()->enabled(kDeviceFanTapPotionQuietly);
                    break;
                case event::AppDeviceDataEvent::AppFanTapPotionLow:
                    //device_manager_->getFan()->enabled(kDeviceFanTapPotionLow);
                    break;
                case event::AppDeviceDataEvent::AppFanTapPotionPowerful:
                    //device_manager_->getFan()->enabled(kDeviceFanTapPotionPowerful);
                    break;
                case event::AppDeviceDataEvent::AppFanTapPotionMax:
                    //device_manager_->getFan()->enabled(kDeviceFanTapPotionMax);
                    break;
                default:
                    break;
            }
        }
        break;

        case event::AppDeviceDataEvent::tank :
        {
            //app_handler_->responseDeviceData(-1,device_data->level);
            if (robot_state_manager_->isStandby() || robot_state_manager_->isCharging()){
                LOGI(TAG,"robot is standby.can not enabled the tank");
                switch(device_data->level)
                {
                case event::AppDeviceDataEvent::AppTankLevelHeight:
                    //device_manager_->getTank()->setTankConfig(kDeviceTankLevelHigh);
                    break;

                case event::AppDeviceDataEvent::AppTankLevelMiddle:
                    //device_manager_->getTank()->setTankConfig(kDeviceTankLevelMiddle);
                    break;

                case event::AppDeviceDataEvent::AppTankLevelLow:
                    //device_manager_->getTank()->setTankConfig(kDeviceTankLevelLow);
                    break;

                default:
                    break;
                }
                return;
            }
            switch(device_data->level)
            {
            case event::AppDeviceDataEvent::AppTankLevelHeight:
                //device_manager_->getTank()->setTankLevel(kDeviceTankLevelHigh);
                break;

            case event::AppDeviceDataEvent::AppTankLevelMiddle:
                //device_manager_->getTank()->setTankLevel(kDeviceTankLevelMiddle);
                break;

            case event::AppDeviceDataEvent::AppTankLevelLow:
                //device_manager_->getTank()->setTankLevel(kDeviceTankLevelLow);
                break;
            }
        }
        break;

        default:
            break;
    }
}

void RobotController::handleAppointmentsEvent(std::shared_ptr<event::Event> event)
{
    std::shared_ptr<event::Appointment> appointment_event = std::dynamic_pointer_cast<event::Appointment>(event);

    //AppointmentData tmp_data;
    int tmp_week;

    switch(appointment_event->event_)
    {
        case event::Appointment::addAppointment:
        {
            //tmp_data.time = appointment_event->data.sweep_count;
            //tmp_data.fan_level = appointment_event->data.fan_level;
            //tmp_data.tank_level = appointment_event->data.water_level;
            //tmp_data.clean_mode = appointment_event->data.clean_mode;
            //tmp_data.id = appointment_event->data.room_id;
            
            //tmp_data.id = configuration_manager_->add<AppointmentData>(tmp_data);

            //ScheduleManager::ScheduleData schedule_data;
            //schedule_data.appointment_time.tm_hour = appointment_event->data.hour;
            //schedule_data.appointment_time.tm_min = appointment_event->data.min;
            //schedule_data.appointment_time.tm_sec = 0;
     
            if(appointment_event->data.week == 0){
                //schedule_data.appointment_time.tm_wday = 7;     //7表示未选星期
                //schedule_manager_->addScheduleTask(schedule_data);
            } else{
                //LOGI(TAG, "appointment_event->data.week=%d",appointment_event->data.week);
                for(int i = 0; i<7; i++)
                {
                    if((appointment_event->data.week >> i) & 0x01){
                        //schedule_data.appointment_time.tm_wday = i+1;
                        //if(schedule_data.appointment_time.tm_wday > 6){
                        //    schedule_data.appointment_time.tm_wday = 0;
                        //}
                        //schedule_manager_->addScheduleTask(schedule_data);
                    }
                }
            }
        }
        break;
        case event::Appointment::deleteAppointment:
        break;
        case event::Appointment::syncAppointment:
        break;
    }
}

void RobotController::handleRemoteControlEvent(std::shared_ptr<event::Event> event)
{
    std::shared_ptr<event::RemoteControl> remote_control_event = std::dynamic_pointer_cast<event::RemoteControl>(event);
    bool success = false;

    if (robot_state_manager_->isWarning()){
        LOGE(TAG, "robot is warning, it can not use the remotecontroll");
        return;
    }
    switch (remote_control_event->code_)
    {
        case event::RemoteControl::REMOTECONTROL_IR_FRONT_KEY:
            //success = navigation_handler_->RemoteControlCommand(REMOTE_CONTROL_GO);
            if (success == false){
                LOGE(TAG, "send remotecontrol command go fail");
            } else{
                LOGI(TAG, "send remotecontrolcommand go success");
            }
            break;

        case event::RemoteControl::REMOTECONTROL_IR_LEFT_KEY:
            //success = navigation_handler_->RemoteControlCommand(REMOTE_CONTROL_TURN_LEFT);
            if (success == false){
                LOGE(TAG, "send remotecontrol command left fail");
            } else{
                LOGI(TAG, "send remotecontrol command left success");
            }
            break;

        case event::RemoteControl::REMOTECONTROL_IR_RIGHT_KEY:
            //success = navigation_handler_->RemoteControlCommand(REMOTE_CONTROL_TURN_RIGHT);
            if (success == false){
                LOGE(TAG, "send remotecontrol command right fail\n");
            } else{
                LOGI(TAG, "send remotecontrolcommand right success\n");
            }
            break;

        case event::RemoteControl::REMOTECONTROL_IR_BEHIND_KEY:
            //success = navigation_handler_->RemoteControlCommand(REMOTE_CONTROL_TURN_BACK);
            if (success == false){
                LOGE(TAG, "send remotecontrol command turn back fail");
            } else{
                LOGI(TAG, "send remotecontrol command turn back success");
            }
            break;

        case event::RemoteControl::REMOTECONTROL_IR_AUTOCLEAN:
            state_machine::RobotModeAutoClean mode_auto_clean;
            state_machine::send_event(mode_auto_clean);
            break;
        
        case event::RemoteControl::REMOTECONTROL_IR_AUTOCLEANSTOP:
            state_machine::RobotModeNone mode_none;
            state_machine::send_event(mode_none);
            break;

        case event::RemoteControl::REMOTECONTROL_IR_FINDSWEEPER:
            state_machine::RobotModeRandom random;
            state_machine::send_event(random);
            break;

        case event::RemoteControl::REMOTECONTROL_IR_ALONGWALLCLEAN:
            state_machine::RobotModeAlongWall alone;
            state_machine::send_event(alone);
            break;

        case event::RemoteControl::REMOTECONTROL_IR_ALONGWALLCLEANSTOP:
            state_machine::RobotModeNone none;
            state_machine::send_event(none);
            break;

        case event::RemoteControl::REMOTECONTROL_IR_WATERFANGEARHIGH:
            if (robot_state_manager_->isStandby() || robot_state_manager_->isCharging()){
                LOGI(TAG, "robot is standby. use remotecontrol set fan height failed");
                //device_manager_->getFan()->setLevelConfig(kDeviceFanTapPotionPowerful);
                //app_handler_->responseDeviceData(AppFanTapPotionPowerful,-1);
            } else{
                //device_manager_->getFan()->enabled(kDeviceFanTapPotionPowerful);
                //app_handler_->responseDeviceData(AppFanTapPotionPowerful,-1);
            }
            break;

        case event::RemoteControl::REMOTECONTROL_IR_WATERFANGEARMID:
            if (robot_state_manager_->isStandby() || robot_state_manager_->isCharging() ){
                LOGI(TAG, "robot is standby. use remotecontrol set fan middle failed");
                //device_manager_->getFan()->setLevelConfig(kDeviceFanTapPotionStandard);
                //app_handler_->responseDeviceData(AppFanTapPotionStandard,-1);
            } else{
                //app_handler_->responseDeviceData(AppFanTapPotionStandard,-1);
                //device_manager_->getFan()->enabled(kDeviceFanTapPotionStandard);
            }
            break;

        case event::RemoteControl::REMOTECONTROL_IR_WATERFANGEARLOW:
            if (robot_state_manager_->isStandby() || robot_state_manager_->isCharging()){
                LOGI(TAG, "robot is standby. use remotecontrol set fan low failed ");
                //device_manager_->getFan()->setLevelConfig(kDeviceFanTapPotionLow);
                //app_handler_->responseDeviceData(AppFanTapPotionLow,-1);
            } else{
                //device_manager_->getFan()->enabled(kDeviceFanTapPotionLow);
                //app_handler_->responseDeviceData(AppFanTapPotionLow,-1);
            }
            break;

        default:
            break;
    }    
}

void RobotController::handleRobotModeEvent(std::shared_ptr<event::Event> event)
{
    auto robot_mode_event = std::dynamic_pointer_cast<event::RobotMode>(event);
    bool success = false;
    int charge_mode;

    LOGI(TAG, "mode event %d.  clean mode event%d",robot_mode_event->mode_event_,robot_mode_event->clean_mode_event_);

    switch (robot_mode_event->clean_mode_event_)
    {
    case event::RobotMode::kAutoClean:
        state_machine::RobotModeAppAction action;
        state_machine::send_event(action);
        break;

    case event::RobotMode::kRecharge:
        state_machine::Recharge mode_recharge;
        state_machine::send_event(mode_recharge); 
        charge_mode = robot_mode_event->charge_mode_event_;
        //success = navigation_handler_->charge(charge_mode);
        if (success == false){
            LOGE(TAG, "send charge mode[%d] to navigation fail", charge_mode);
        } else{
            LOGI(TAG, "send charge mode[%d] to navigation success", charge_mode);
        }
        break;

    case event::RobotMode::kPartitionZoneClean:
#if 0
        switch (robot_mode_event->zone_data.zone_mode)
        {
        case kAppPartitionZone:
            //success = slam_handler_->send_clean_data(robot_mode_event->zone_data);
            if (success == false){
                LOGE(TAG, "send clean_zone_data to slam fail\n");
            } else{
                LOGI(TAG, "send clean_zone_data to slam success\n");
            }
            state_machine::RobotPartitionClean partition_clean;
            state_machine::send_event(partition_clean);
            //partition_clean.clean_zone_data = robot_mode_event->zone_data;
            //success = navigation_handler_->partition_zone_clean(partition_clean.clean_zone_data);
            if (success == false){
                LOGE(TAG, "send clean_zone_data to navigation fail\n");
            } else{
                LOGI(TAG, "send clean_zone_data to navigation success\n");
            }
            break;

        case kAppForbidenZone:
            //success = slam_handler_->send_clean_data(robot_mode_event->zone_data);
            if (success == false){
                LOGE(TAG, "send forbiden_zone_data to slam fail");
            } else{
                LOGI(TAG, "send forbiden_zone_data to slam success");
            } 
            //success = navigation_handler_->partition_zone_clean(robot_mode_event->zone_data);
            if (success == false){
                LOGE(TAG, "send forbiden_zone_data to navigation fail");
            } else{
                LOGI(TAG, "send forbiden_zone_data to navigation success");
            } 
            break;

        default:
            break;
        }
#endif
        break;

    case event::RobotMode::kFixedPointClean:
        state_machine::RobotPointClean point_clean;
        state_machine::send_event(point_clean);
        //point_clean.clean_point_data = robot_mode_event->fixPoint_data;
        //success = slam_handler_->send_fix_point(point_clean.clean_point_data);
        if (success == false){
            LOGE(TAG, "send clean_fixPoint_data fail");
        } else{
            LOGI(TAG, "send clean_fixPoint_data success");
        }
        break;

    case event::RobotMode::kNoneCleanMode:
        state_machine::RobotModeNone none;
        state_machine::send_event(none);
        break;

    default:
        break;
    }

    switch (robot_mode_event->mode_event_)
    {
        case event::RobotMode::kChanging:
            state_machine::RobotCharging mode_charging;
            state_machine::send_event(mode_charging);
            break;

        case event::RobotMode::kNoneMode:
            state_machine::RobotModeNone none;
            state_machine::send_event(none);
            break;
        
        case event::RobotMode::kChangingBeMove:
            state_machine::RobotChargingBeMove move;
            state_machine::send_event(move);
            break;

        default:
            break;
    }
}

void RobotController::handleNavigationEvent(std::shared_ptr<event::Event> event)
{
    std::shared_ptr<event::Navigation> navigation_event = std::dynamic_pointer_cast<event::Navigation>(event);
    bool success = false;

    switch (navigation_event->event_)
    {
        case event::Navigation::kPrepared_planning:        
        {
            state_machine::RobotModeAutoClean action;
            state_machine::send_event(action);
            //success = navigation_handler_->stop();  //给导航发送stop信号
            if (success == false){
                LOGE(TAG, "send stop false");
            } else{
                LOGI(TAG, "send stop success");
            }
            break;
        }
        case event::Navigation::kNeedRecharge:
        {
            g_charge_flag = true;
            state_machine::Recharge mode_need_recharge;
            state_machine::send_event(mode_need_recharge);
            LOGI(TAG, "the navigation_handler tell is need to recharge");
            //device_manager_->syncChassisMode_UptoRecharge();       //执行上充电座动作
            break;
        }
        case event::Navigation::kSearchCharger:
        {
            //app_handler_->machineStateUpload_Recharge();
            break;
        }
        case event::Navigation::kTaskFailed:
        {
            state_machine::RobotModeNone mode_none;
            state_machine::send_event(mode_none);
            break;
        }
        case event::Navigation::kCleanAreaUpload:
        {
            //this->app_handler_->cleanareaUpload(navigation_event->clean_area);//for tmp debug
            //此处触发APP服务
            break;
        }

        default:
        break;
    }
}

void RobotController::handleAlarmMangerEvent(std::shared_ptr<event::Event> event)
{
    std::shared_ptr<event::Alarm> alarm_event = std::dynamic_pointer_cast<event::Alarm>(event);
    bool success = false;

    switch(alarm_event->event_)
    {
        case event::Alarm::appointmentClean:
            LOGI(TAG,"start appointmentClean");
            state_machine::RobotModeAutoClean appoint_auto_clean;
            state_machine::send_event(appoint_auto_clean);
            break;
        default:
            break;
    }
}

void RobotController::handleSlamEvent(std::shared_ptr<event::Event> event)
{
    auto slam_event = std::dynamic_pointer_cast<event::Slam>(event);
    switch (slam_event->event_)
    {
        case event::Slam::relocation_success:
        {
            // state_machine::RobotModeAutoClean action;
            // state_machine::send_event(action);
        }
        break;

        case event::Slam::relocation_failed:
        {
            
        }
        break;

        default:
        break;
    }
}

void RobotController::handleSideBrushConditionEvent(std::shared_ptr<event::Event> event)
{
    bool success = false;
    // auto side_brush_condition = std::dynamic_pointer_cast<event::SideBrushCondition>(event);

    //success = task_manager_->sendEvent(event);
    if (success == false) {
        LOGE(TAG, "send side brush condition failed");
    }
}

void RobotController::handleWheelConditionEvent(std::shared_ptr<event::Event> event)
{
    std::shared_ptr<event::WheelCondition> wheelCondition_event = std::dynamic_pointer_cast<event::WheelCondition>(event);

    switch(wheelCondition_event->condition_type) 
    {
        case event::WheelCondition::left_locker_rotor:
        {
            //navigation_handler_->wheelLockedRotor();
            LOGE(TAG, "robot left wheel is locker_rotor");
        }
        break;

        case event::WheelCondition::right_locker_rotor:
        {
            //navigation_handler_->wheelLockedRotor();
            LOGE(TAG, "robot right wheel is locker_rotor");
        }
        break;

        case event::WheelCondition::both_locker_rotor:
        {
            //navigation_handler_->wheelLockedRotor();
            LOGE(TAG, "robot left and right wheel is locker_rotor");
        }
        break;

        default:
        break;
    }
}

void RobotController::handleGroundCheckConditionEvent(std::shared_ptr<event::Event> event)
{
    std::shared_ptr<event::GroundCheckerCondition> ground_checker_event = std::dynamic_pointer_cast<event::GroundCheckerCondition>(event);
    switch (ground_checker_event->condition_type)
    {
    case event::GroundCheckerCondition::kMachinePullup:
        state_machine::RobotWaring warning;
        state_machine::send_event(warning);
        //device_manager_->disableLidarDevice();
        break;

    case event::GroundCheckerCondition::kMachineOnGround:
        state_machine::RobotSafe safe;
        state_machine::send_event(safe);
        //device_manager_->enabledLidarDevice();
        break;

    default:
        break;
    }
}
