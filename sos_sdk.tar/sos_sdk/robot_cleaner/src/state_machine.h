#ifndef STATE_MACHINE_H
#define STATE_MACHINE_H

#include <tinyfsm.hpp>
#include "robot_state_machine.h"

namespace state_machine {

// using fsm_list = tinyfsm::FsmList<Motor, Elevator>;
using fsm_list = tinyfsm::FsmList<RobotStateMachine>;

/** dispatch event to both "RobotStateMachine" and "Other in fsm_list" */
template<typename E>
void send_event(E const & event)
{
  fsm_list::template dispatch<E>(event);
}

}

#endif
