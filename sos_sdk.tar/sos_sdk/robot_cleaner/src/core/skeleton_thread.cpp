#include <stdio.h>
#include <typeinfo>
#include "skeleton_thread.h"
#include "logger_rc.h"
#include "logger.h"

LOG_MOD_DECLARE(TAG, DEBUG_SKELETON_THREAD);

SkeletonThread::SkeletonThread()
{
    running = false;
}

SkeletonThread::~SkeletonThread()
{
    if (running) {
        LOGD(TAG, "Service %s thread still running at destructor, stop and join", name_.c_str());
        stop();
    }
}

void SkeletonThread::start()
{
    thread_ = std::make_shared<std::thread>(&SkeletonThread::threadFunction, this);
    LOGD(TAG, "start thread id %u", thread_->get_id());
}

void SkeletonThread::stop()
{
    if (running) {
        running = false;
        onStop();
        LOGD(TAG, "exit thread id %u", thread_->get_id());
        thread_->join();
        thread_ = nullptr;
    }
}

bool SkeletonThread::isRunning()
{
    return running;
}

void SkeletonThread::threadFunction()
{
    bool exec;
    std::string tmp_name;

    name_ = typeid(*this).name();
    LOGD(TAG, "Service %s thread start", name_.c_str());

    running = true;

    if (name_.size() > 15) {
        tmp_name = name_.substr(0, 15);
    } else {
        tmp_name = name_;
    }

    pthread_setname_np(pthread_self(), tmp_name.c_str());

    onStart();

    while (running) {
        exec = threadLoop();
        if (!exec) {
            break;
        }
    }

    LOGD(TAG, "Service %s thread stop", name_.c_str());

    onStop();
}

void SkeletonThread::onStart()
{

}

void SkeletonThread::onStop()
{

}

bool SkeletonThread::threadLoop()
{
    return false;
}
