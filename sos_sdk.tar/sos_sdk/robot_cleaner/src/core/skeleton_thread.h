#ifndef _SKELETION_THREAD_H_
#define _SKELETION_THREAD_H_

#include <string>
#include <memory>
#include <thread>

class SkeletonThread
{
public:
    SkeletonThread();
    ~SkeletonThread();

    void start();
    void stop();
    bool isRunning();

protected:
    virtual void onStart();
    virtual void onStop();
    virtual bool threadLoop();

private:
    void threadFunction();

protected:
    std::shared_ptr<std::thread> thread_;
    bool running;
    std::string thread_name_;
    std::string name_;
};

#endif /* _SKELETION_THREAD_H_ */
