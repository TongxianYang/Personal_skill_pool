/*
 * 设备管理模块 对风机、边刷、滚刷、LED进行管理控制
 * 
*/
#include <cmath>
//#include <core/log.h>
//#include <core/utils.h>
#include "device_manager.h"
#include "logger.h"
#include "logger_rc.h"

LOG_MOD_DECLARE(TAG, DEBUG_DEVICE_MANAGER);


std::shared_ptr<DeviceManager> DeviceManager::Instance_ = nullptr;
std::mutex DeviceManager::mutex_;
static const int BATVOLTAGE_THRESHOLD = 5;
static const int SECOND = 1;
static const int LOWPOWER = 14;
static const int time_interval = 5000;  //5s
static int time_count = 0;
static bool trigger_flag = false;


std::shared_ptr<DeviceManager> DeviceManager::getInstance()
{
    if (Instance_ == nullptr){
        mutex_.lock();
        if (Instance_ == nullptr){
            Instance_ = std::make_shared<DeviceManager>();
            LOGI(TAG, "make instance success");
        }
        mutex_.unlock();
    }

    return Instance_;
}

void DeviceManager::onStart()
{
    //ChassisProtocol_->connectedRpc();
}

bool DeviceManager::threadLoop()
{
#if 0
    int warning_error_code  = 0;
    std::shared_ptr<event::Event>  event_ = nullptr;
    event::Key::KeyCode keyCode = last_keyCode_;

    /*
    this code can rebuild. there are so many repetition code. 
    event update code;
    
    */
   
    auto RemoteValue = ChassisProtocol_->getKeyData();
    auto AlertMode = ChassisProtocol_->getAlertModeData();
    auto batteryData = ChassisProtocol_->getPowerSupplyData();

    warning_error_code = *AlertMode;
    Button_->setKeyValue(*RemoteValue);
    Button_->getKeyValue(keyCode); 
    
    robotModeUpdate();

    deviceBatUpdate();

    if (keyCode != last_keyCode_ && keyCode != event::Key::kKeyCodeNone){
        std::shared_ptr<event::Key> key_event = std::make_shared<event::Key>();

        keyEventUpdate(keyCode,key_event);

        event_ = std::dynamic_pointer_cast<event::Event>(key_event);
        if (event_ != nullptr) {
            log_info(TAG, "Key Event report success event:%d",key_event->code_); 
            callback_(event_);
        }
    }

    if (RemoteValue->keyCode > event::RemoteControl::REMOTECONTROL_IR_NONE && RemoteValue->keyCode < 99){
        std::shared_ptr<event::RemoteControl> remoteControl_event = std::make_shared<event::RemoteControl>();

        remoteControlEventUpdate(*RemoteValue,remoteControl_event);

        event_ = std::dynamic_pointer_cast<event::Event>(remoteControl_event);
        if (event_ != nullptr) {
            log_info(TAG, "remoteControl Event report success event:%d",remoteControl_event->code_); 
            callback_(event_);
        }
    }

    /*batValue update*/
    if (batteryData->batVolume != last_batValue_){
        std::shared_ptr<event::Battery> battery_event = std::make_shared<event::Battery>();

        battery_event->event_ = event::Battery::kBatteryValueUpdate;
        battery_event->batteryValue_ = batteryData->batVolume;

        event_ = std::dynamic_pointer_cast<event::Battery>(battery_event);
        log_info(TAG, "update Bat:%d",battery_event->batteryValue_);
        callback_(event_); 
    }

    /*low battery event*/
    if(batteryData->batVolume <= LOWPOWER){
        if(false == trigger_flag){
            time_count++;
        }   
        if(time_count >= time_interval){
            if(batteryData->batVolume <= LOWPOWER){
                trigger_flag = true;
                log_info(TAG, "low power trigger battery_event");
                std::shared_ptr<event::Battery> battery_event = std::make_shared<event::Battery>();
                battery_event->event_ = event::Battery::kLowPowerLevelOne;

                event_ = std::dynamic_pointer_cast<event::Battery>(battery_event);
                callback_(event_);
            }
            time_count = 0;
        }
      
    } else{
        trigger_flag = false;
    }

    last_batVoltage_ = batteryData->batVoltage;
    last_batValue_ = batteryData->batVolume;
    last_keyCode_ = keyCode;

    msleep(1);
#endif //
    return true;
}

#if 0
void DeviceManager::deviceBatUpdate()
{
    
    if(deviceBat_count >= 100){
        deviceBat_count = 0;
        Fan_->update();
    }
    deviceBat_count++;

}

void DeviceManager::robotModeUpdate()
{
    std::shared_ptr<event::Event>  event = nullptr;
    std::shared_ptr<event::RobotMode> robotModeEvent = std::make_shared<event::RobotMode>();

    robotModeEvent->mode_event_ = last_RobotMode_;
    robotModeEvent->clean_mode_event_ = event::RobotMode::kCleanModeInvalid;

    if (Battery_->isCharging()){
        robotModeEvent->mode_event_ = event::RobotMode::kChanging;
    } else if (Battery_->isDcCharging()){
        robotModeEvent->mode_event_ = event::RobotMode::kDcCharging;
    } /*(else if (!Battery_->isPowerOn()){
        robotModeEvent->mode_event_ = event::RobotMode::kPowerOFF;
    // } */else {
        robotModeEvent->mode_event_ = event::RobotMode::kChangingBeMove;
    }

    if (robotModeEvent->mode_event_ != last_RobotMode_){
        event = std::dynamic_pointer_cast<event::Event>(robotModeEvent);
        log_info(TAG, "Robot Mode Event report success Mode event:%d ,clean mode event:%d ",robotModeEvent->mode_event_,robotModeEvent->clean_mode_event_); 
        if (event != nullptr) {
            callback_(event);
        }
    }
    last_RobotMode_ = robotModeEvent->mode_event_;
    
}

void DeviceManager::batteryEventUpdate(const int &data,std::shared_ptr<event::Battery> event_)
{
    switch(data)
    {
        case event::Battery::BatteryEvent::kAdapterException:
            event_->event_ = event::Battery::BatteryEvent::kAdapterException;
        break;

        case event::Battery::BatteryEvent::kChagerWarning:
            event_->event_ = event::Battery::BatteryEvent::kChagerWarning;
        break;

        case event::Battery::BatteryEvent::kLowPowerLevelOne:
            event_->event_ = event::Battery::BatteryEvent::kLowPowerLevelOne;
        break;

        case event::Battery::BatteryEvent::kLowPowerLevelTwo:
            event_->event_ = event::Battery::BatteryEvent::kLowPowerLevelTwo;
        break;
        default:
        break;
    }
}

void DeviceManager::robotModeUpdate(std::shared_ptr<RobotMode_t> mode,std::shared_ptr<event::RobotMode> event)
{
 
}

void DeviceManager::keyEventUpdate(event::Key::KeyCode &key, std::shared_ptr<event::Key> keyEvent_)
{
    keyEvent_->code_ = event::Key::KeyCode(key);
}
void DeviceManager::remoteControlEventUpdate(const struct KeyData_t &key, std::shared_ptr<event::RemoteControl> RemoteEvent_)
{
    RemoteEvent_->code_ = event::RemoteControl::RemoteControlCode(key.keyCode);
}

void DeviceManager::alertEventUpdate(const AlertMode_t &data,std::shared_ptr<event::Alert> event)
{
    event->event_ = event::Alert::AlertEvent(data);
}
#endif

DeviceManager::DeviceManager():last_RobotMode_(event::RobotMode::kNoneMode)
{
}

DeviceManager::~DeviceManager()
{
}

bool DeviceManager::init()
{
    // bool rc;
    // this->ChassisProtocol_ = ChassisProtocol::getInstance();

    // rc = this->ChassisProtocol_->init();
    // if (rc == false){
    //     log_error(TAG, "chassis protocol normal init failed");
    //     return false;
    // }

    // rc = this->deviceInit();
    // if(rc == false){
    //     log_error(TAG, "[DeviceManager] Device init false");
    //     return false;
    // }

    // last_batVoltage_ = ChassisProtocol_->getPowerSupplyData()->batVoltage;
    
    // charging_count = 0; 
    
    // deviceBat_count = 0;

    // task_flag = false;
    
    // log_info(TAG, "[DeviceManager] DeviceManager init success");
    return true;
}
#if 0
void DeviceManager::setEventReportCallback(event::event_callback callback)
{
    callback_ = callback;
}

bool DeviceManager::deviceInit()
{
    bool rc;

    this->Fan_ = std::make_shared<Fan>();
    if (Fan_ == nullptr){
        log_error(TAG,"fan make shared false");
        return false;
    }
    this->Led_ = std::make_shared<Led>();
    if (Led_  == nullptr){
        log_error(TAG,"Led_  make shared false");
        return false;        
    }
    this->LoudSpeaker_ = std::make_shared<LoudSpeaker>();
    if (LoudSpeaker_ == nullptr){
        log_error(TAG,"LoudSpeaker_ make shared false");
        return false;
    }
    this->RollingBrash_ = std::make_shared<RollingBrush>();
    if (RollingBrash_ == nullptr){
        log_error(TAG,"RollingBrash_ make shared false");
        return false;
    }
    this->SideBrush_ = std::make_shared<SideBrush>();
    if (SideBrush_ == nullptr){
        log_error(TAG,"SideBrush_ make shared false");
        return false;
    }
    this->Tank_ = std::make_shared<Tank>();
    if (Tank_ == nullptr){
        log_error(TAG,"Tank_ make shared false");
        return false;
    }
    this->RemoteControl_ = std::make_shared<RemoteControl>();
    if (RemoteControl_  == nullptr){
        log_error(TAG,"RemoteControl_  make shared false");
        return false;
    }
    this->Battery_ = std::make_shared<Battery>();
    if (Battery_ == nullptr){
        log_error(TAG,"Battery_ make shared false");
        return false;
    }
    this->Caddy_ = std::make_shared<Caddy>();
    if (Caddy_ == nullptr){
        log_error(TAG,"Caddy_ make shared false");
        return false;
    }
    this->Crash_ = std::make_shared<Crash>();
    if (Crash_ == nullptr){
        log_error(TAG,"Crash_ make shared false");
        return false;
    }
    this->GYRO_ = std::make_shared<GYRO>();
    if (GYRO_ == nullptr){
        log_error(TAG,"GYRO_ make shared false");
        return false;
    }
    this->Mop_ = std::make_shared<Mop>();
    if (Mop_ == nullptr){
        log_error(TAG,"Mop_ make shared false");
        return false;
    }
    this->OmnibearingSensor_ = std::make_shared<OmnibearingSensor>();
    if (OmnibearingSensor_ == nullptr){
        log_error(TAG,"OmnibearingSensor_ make shared false");
        return false;
    }
    this->GroundChecker_ = std::make_shared<GroundChecker>();
    if (GroundChecker_ == nullptr){
        log_error(TAG,"GroundChecker_ make shared false");
        return false;
    }
    this->AlongWall_ = std::make_shared<AlongWall>();
    if (AlongWall_ == nullptr){
        log_error(TAG,"GroundChecker_ make shared false");
        return false;
    }

    this->Button_ = std::make_shared<Button>();
    if (Button_ == nullptr){
        log_error(TAG,"Button_ make shared false");
        return false;
    }

    this->OnOffButton_ = std::make_shared<OnOffButton>();
    if (OnOffButton_ == nullptr){
        log_error(TAG,"on off button make shared false");
        return false;
    }
    this->Wheel_ = std::make_shared<Wheel>();
    if (Wheel_ == nullptr){
        log_error(TAG,"wheel make shared false");
        return false;
    }

    this->Lidar_ = std::make_shared<Lidar>();
    if (Lidar_ == nullptr){
        log_error(TAG,"lidar make shared false");
        return false;
    }

    rc = this->LoudSpeaker_->init();
    if (rc == false){
        log_error(TAG, "[DeviceManager] LoudSpeaker init false");
    }

    ChassisProtocol_->setSideBrush(0,0);
    ChassisProtocol_->setFanLevel(0);
    ChassisProtocol_->setRollingBrushLevel(0);
    Led_->setWifiConfig(kDeviceLedColorBlue,kDeviceLedIndexOFF);
    Led_->setPowerLedConfig(kDeviceLedColorBlue,kDeviceLedIndexOn);

    log_info(TAG,"[DeviceManager] device init success");
    return true;
}

std::shared_ptr<Battery> DeviceManager::getBattery()
{
    return Battery_;
}

std::shared_ptr<GYRO> DeviceManager::getGYRO()
{
    return this->GYRO_;
};

std::shared_ptr<GroundChecker> DeviceManager::getGroundChecker()
{
    return this->GroundChecker_;
}

std::shared_ptr<AlongWall> DeviceManager::getAlongWall()
{
    return this->AlongWall_;
}

std::shared_ptr<Crash> DeviceManager::getCrash()
{
    return this->Crash_;
}

std::shared_ptr<Caddy> DeviceManager::getCaddy()
{
    return this->Caddy_;
}

std::shared_ptr<Mop> DeviceManager::getMop()
{
    return this->Mop_;
}

std::shared_ptr<OmnibearingSensor> DeviceManager::getOmnibearingSensor()
{
    return this->OmnibearingSensor_;
}

//can control can DeviceManager::get info
std::shared_ptr<SideBrush> DeviceManager::getSideBrush()
{
    return this->SideBrush_;
}

std::shared_ptr<RollingBrush> DeviceManager::getRollingBrash()
{
    return this->RollingBrash_;
}

std::shared_ptr<Tank> DeviceManager::getTank()
{
    return this->Tank_;
}

std::shared_ptr<Fan> DeviceManager::getFan()
{
    return this->Fan_;
}
std::shared_ptr<Lidar> DeviceManager::getLidar()
{
    return this->Lidar_;
}

//can control can't DeviceManager::get info
std::shared_ptr<Led> DeviceManager::getLed()
{
    return this->Led_;
}

std::shared_ptr<LoudSpeaker> DeviceManager::getLoudSpeaker()
{
    return this->LoudSpeaker_;
}

std::shared_ptr<RemoteControl> DeviceManager::getRemoteControl()
{
    return this->RemoteControl_;
}

std::shared_ptr<Button> DeviceManager::getButton()
{
    return this->Button_;
}

std::shared_ptr<OnOffButton> DeviceManager::getOnOffButton()
{
    return this->OnOffButton_;
}

std::shared_ptr<Wheel> DeviceManager::getWheel()
{
    return this->Wheel_;
}

void DeviceManager::setRobotModeAuto()
{
    ChassisProtocol_->setRobotMode(ROBOT_MODE_AUTO);
}

void DeviceManager::setRobotModeStandBy()
{
    ChassisProtocol_->setRobotMode(ROBOT_MODE_NONE);
}

void DeviceManager::setRobotModeFixedPoint()
{
    ChassisProtocol_->setRobotMode(ROBOT_MODE_FIXED_POINT);
}

void DeviceManager::setRobotModeAlongWall()
{
    ChassisProtocol_->setRobotMode(ROBOT_MODE_ALONG_WALL);
}

void DeviceManager::setRobotModeRandom()
{
    ChassisProtocol_->setRobotMode(ROBOT_MODE_RANDOM);
}

void DeviceManager::setRobotModeRecharge()
{
    ChassisProtocol_->setRobotMode(ROBOT_MODE_RECHARGE);
}

void DeviceManager::setRobotModeNone()
{
    ChassisProtocol_->setRobotMode(ROBOT_MODE_NONE);
}

void DeviceManager::enabled(std::shared_ptr<Device> device)
{
    device->enabled();
}

void DeviceManager::disabled(std::shared_ptr<Device> device)
{
    device->disabled();
}
void DeviceManager::enabledCleningDevice()
{
    this->Fan_->enabled();
    this->RollingBrash_->enabled();
    this->SideBrush_->enabled();
}

void DeviceManager::disabledCleningDevice()
{
    this->Fan_->disabled();
    this->RollingBrash_->disabled();
    this->SideBrush_->disabled();
}

void DeviceManager::enabledLidarDevice()
{
    this->Lidar_->enabled();
}

void DeviceManager::disableLidarDevice()
{
    this->Lidar_->disabled();
}

int DeviceManager::getRobotModeState()
{
    return last_RobotMode_;
}

bool DeviceManager::setRobotModeEvent_None()
{
    last_RobotMode_ = event::RobotMode::kNoneMode;
    return true;
}

bool DeviceManager::isAllow()
{
    return task_flag == true;
}

void DeviceManager::notAllow()
{
    task_flag = false;
}
void DeviceManager::allow()
{
    task_flag = true;
}

bool DeviceManager::syncChassisMode_Standby()
{
    ChassisProtocol_->setRobotMode(ChassisModeStandby);
    return true;

}

bool DeviceManager::syncChassisMode_Runing()
{
    ChassisProtocol_->setRobotMode(ChassisModeRuning);
    return true;
}

bool DeviceManager::syncChassisMode_UptoRecharge()
{
    ChassisProtocol_->setRobotMode(ChassisModeUptoRecharge);
    return true;
}

bool DeviceManager::syncChassisMode_OutOfTrouble()
{
    log_error(TAG, "bad mode");
    return true;
}

bool DeviceManager::syncChassisMode_FixedPointClean()
{
    ChassisProtocol_->setRobotMode(ChassisModeFixedPoint);
    return true;
}

bool DeviceManager::syncChassisMode_AlongWall()
{
    ChassisProtocol_->setRobotMode(ChassisModeAlongWall);
    return true;
}

bool DeviceManager::syncChassisMode_Charging()
{
    ChassisProtocol_->setRobotMode(ChassisModeCharging);
    return true;
}

bool DeviceManager::syncChassisMode_Random()
{
    ChassisProtocol_->setRobotMode(ChassisModeRandom);
    return true;
}

#endif