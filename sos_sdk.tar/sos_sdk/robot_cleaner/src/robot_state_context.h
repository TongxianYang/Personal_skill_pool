#ifndef ROBOT_STATE_CONTEXT_H
#define ROBOT_STATE_CONTEXT_H

#include <memory>
//#include <task_manager.h>
//#include <device_manager.h>
//#include <configuration_manager.hpp>
//#include <rpc/navigation_client_handler.h>
//#include <rpc/app_handler.h>
//#include <rpc/slam_handler.h>
#include "robot_state_manager.h"

namespace state_machine {

class RobotStateContext
{
public:
    //std::shared_ptr<NavigationClientHandler> navigation_handler;
    //std::shared_ptr<SlamHandler> slam_handler;
    //std::shared_ptr<TaskManager> task_manager;
    //std::shared_ptr<DeviceManager> device_manager;
    //std::shared_ptr<AppHandler> app_handler;
    std::shared_ptr<RobotStateManager> robot_state_manager;
    //std::shared_ptr<ConfigurationManager> configuration_manager;
};

}

#endif

