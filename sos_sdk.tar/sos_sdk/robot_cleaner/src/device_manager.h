#ifndef DEVICE_MANAGER_H
#define DEVICE_MANAGER_H
#include <functional>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

#include "key.h"
#include "robot_mode.h"
#include "battery.h"
#include "alert.h"

//#include "chassis_protocol.h"
//#include "user_device_manager.h"
#include "skeleton_thread.h"
#include "queue.h"

//#include "devices.h"

/* The DeviceServer Manager
 * this server is a path of cleanserver, is order to control the devices.
 */

class DeviceManager : public SkeletonThread
{
public:
    DeviceManager();
    ~DeviceManager();

    static std::shared_ptr<DeviceManager> getInstance(); 

    bool init();

    //void enabled(std::shared_ptr<Device> device);
    //void disabled(std::shared_ptr<Device> device);
    //void enabledCleningDevice();
    //void disabledCleningDevice();
    //void enabledLidarDevice();
    //void disableLidarDevice();
    //int getRobotModeState();
    //bool setRobotModeEvent_None();
    //void setEventReportCallback(event::event_callback callback);

    //std::shared_ptr<Battery> getBattery();
    //std::shared_ptr<GYRO> getGYRO();
    //std::shared_ptr<GroundChecker> getGroundChecker();
    //std::shared_ptr<AlongWall> getAlongWall();
    //std::shared_ptr<Crash> getCrash();
    //std::shared_ptr<Caddy> getCaddy();
    //std::shared_ptr<Mop> getMop();
    //std::shared_ptr<OmnibearingSensor> getOmnibearingSensor();

    /* can control can get info */
    //std::shared_ptr<SideBrush> getSideBrush();
    //std::shared_ptr<RollingBrush> getRollingBrash();
    //std::shared_ptr<Tank> getTank();
    //std::shared_ptr<Fan> getFan();
    //std::shared_ptr<Lidar>getLidar();

    /* can control can't get info */
    //std::shared_ptr<Led> getLed();
    //std::shared_ptr<LoudSpeaker> getLoudSpeaker();
    //std::shared_ptr<RemoteControl> getRemoteControl();
    //std::shared_ptr<Button> getButton();
    //std::shared_ptr<OnOffButton> getOnOffButton();
    //std::shared_ptr<Wheel>getWheel();

    /* can't control can get info */
    //void setRobotModeAuto();
    //void setRobotModeStandBy();
    //void setRobotModeFixedPoint();
    //void setRobotModeAlongWall();
    //void setRobotModeRandom();
    //void setRobotModeRecharge();
    //void setRobotModeNone();

    //bool isAllow();
    //void notAllow();
    //void allow();

    //bool syncChassisMode_Standby();
    //bool syncChassisMode_Runing();
    //bool syncChassisMode_UptoRecharge();
    //bool syncChassisMode_OutOfTrouble();
    //bool syncChassisMode_FixedPointClean();
    //bool syncChassisMode_AlongWall();
    //bool syncChassisMode_Charging();
    //bool syncChassisMode_Random();

protected:
    virtual void onStart();
    virtual bool threadLoop();

    //void keyEventUpdate(event::Key::KeyCode &key, std::shared_ptr<event::Key> keyEvent_);
    //void remoteControlEventUpdate(const struct KeyData_t &key, std::shared_ptr<event::RemoteControl> keyEvent_);
    //void batteryEventUpdate(const int &data,std::shared_ptr<event::Battery> event_);
    //void robotModeUpdate(std::shared_ptr<RobotMode_t> mode,std::shared_ptr<event::RobotMode> event);
    //void alertEventUpdate(const AlertMode_t &data,std::shared_ptr<event::Alert> event);
    //void robotModeUpdate();
    //void deviceBatUpdate();
    //bool deviceInit();

private:    
    /* CommunicateChassis */
    static std::shared_ptr<DeviceManager> Instance_;
    static std::mutex mutex_;
    std::function<void(std::shared_ptr<event::Event>)> callback_;

    //std::shared_ptr<ChassisProtocol> ChassisProtocol_;
    //std::shared_ptr<Battery> Battery_;
    //std::shared_ptr<Wheel> Wheel_;
    //std::shared_ptr<GYRO> GYRO_;
    //std::shared_ptr<GroundChecker> GroundChecker_;
    //std::shared_ptr<AlongWall> AlongWall_;
    //std::shared_ptr<Crash> Crash_;
    //std::shared_ptr<Caddy> Caddy_;
    //std::shared_ptr<Mop> Mop_;
    //std::shared_ptr<OmnibearingSensor> OmnibearingSensor_;
    
    /* can control can get info */
    //std::shared_ptr<SideBrush> SideBrush_;
    //std::shared_ptr<RollingBrush> RollingBrash_;
    //std::shared_ptr<Tank> Tank_;
    //std::shared_ptr<Fan> Fan_;
    //std::shared_ptr<Lidar>Lidar_;

    /* can control can't get info */
    //std::shared_ptr<Led> Led_;
    //std::shared_ptr<LoudSpeaker> LoudSpeaker_;
    //std::shared_ptr<RemoteControl> RemoteControl_;
    //std::shared_ptr<Button> Button_;
    //std::shared_ptr<OnOffButton> OnOffButton_;

    //event::Key::KeyCode last_keyCode_;
    //uint16_t last_batVoltage_;
    //uint16_t last_batValue_;
    //int charging_count; 
    //int deviceBat_count;
    //std::shared_ptr<Device> Device_;
    event::RobotMode::ModeEvent last_RobotMode_;
    bool task_flag;
};

#endif
