#ifndef NAVIGATION_EVENT_H
#define NAVIGATION_EVENT_H
#include <event/event.h>

namespace event {

class Navigation : public ExceptionEvent {

public:
    Navigation()
    {
        event_ = kNone;
    }
    enum NavigationEvent{
        kNone = 0,
        kTaskFailed = 1,
        kPrepared_planning, // 下回充座完成  
        kNeedRecharge,
        kConditionRobotLockOnChair, //椅子卡死
        kConditionRobotWireWound, // 线缠绕
        kSearchCharger,            //寻找回充座
        kCleanAreaUpload,
    };
    NavigationEvent event_;
    int clean_area;
};

}
#endif // !NAVIGATION_EVENT_H
