#ifndef BATTERY_H
#define BATTERY_H
#include "event.h"

namespace event {

class Battery : public ExceptionEvent {

public:
    Battery()
    {
        event_ = kNone;
    }
    enum BatteryEvent{
        kNone = 0,
        kLowPowerLevelOne = 11,
        kLowPowerLevelTwo = 16,
        kAdapterException = 12, 
        kChagerWarning = 18,
        kBatteryValueUpdate
    };
    BatteryEvent event_;
    int batteryValue_;
};



}


#endif // !BATTERY_H