#ifndef EVENT_KEY_H
#define EVENT_KEY_H

#include "event.h"

namespace event {
    
class Key : public ActionEvent
{
public:
    enum KeyCode {
        kKeyCodeNone = 1,
        kKeyCodeHome = 11,
        kKeyCodeAction = 5,
        kKeyCodeWifi,
        kKeyCodeFixPoint,
    };

    Key() {
        code_ = kKeyCodeNone;
    }
public:
    KeyCode code_;
};

}

#endif
