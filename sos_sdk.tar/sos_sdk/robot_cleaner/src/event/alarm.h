#ifndef ALARM_H
#define ALARM_H
#include <event/event.h>

namespace event {

class Alarm : public Event
{
public:
    enum AlarmEvent{
        appointmentClean,       //预约清扫
        appointmentCleanError,  //预约异常
        timingSleep,            //定时休眠
        timingError,            //定时异常
        countDown,              //倒计时
    };
    
public:
    AlarmEvent event_;
};


}

#endif // !ALARM_H