#ifndef EVENT_H
#define EVENT_H

#include <memory>

namespace event {

class Event;

using event_callback = std::function<void(std::shared_ptr<Event>)>;


class Event
{
public:
    Event() {}
    virtual ~Event() {}
};

class ActionEvent : public Event
{

};

class ExceptionEvent : public Event
{

};

class InfoEvent : public Event
{

};

class ConfigEvent : public Event
{

};

class ConditionEvent : public Event
{

};

}

#endif
