#ifndef NET_WORK_STATE_H
#define NET_WORK_STATE_H
#include <event/event.h>

namespace event {

class NetWorkState : public InfoEvent
{
public:
    enum NetWorkStateEvent{
        kConnected,         //已连接
        kDisconnected,      //未连接
        kConnectedSuccess,  //联网成功
        kConnectedFailed,    //联网失败
        kPreparedConfigNetWork,    //预备配网
    };
    
public:
    NetWorkStateEvent event_;
};


}

#endif // 