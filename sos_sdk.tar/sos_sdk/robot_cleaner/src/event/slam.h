#ifndef SLAM_EVENT_H
#define SLAM_EVENT_H

#include <event/event.h>

namespace event {

class Slam : public ExceptionEvent {

public:
    Slam()
    {
        event_ = kNone;
    }
    enum SlamEvent{
        kNone = 0,
        relocation_failed = 1,
        relocation_success = 2,
    };
    SlamEvent event_;
};

}
#endif