#ifndef APP_COMMAND_H
#define APP_COMMAND_H

#include "event.h"
namespace event{

// class AppCommand : public Event 
// {
// public:
//     AppCommand();
//     enum CommandCode{
//         kStartClean = 1,                //开始清扫
//         kStopClean,                     //暂停清扫
//         KStartRecharge,                 //开始回充
//         kStopRecharge,                  //停止回充
//         kSetFanAndRollingBrushLevel,    //设置风机边刷等级
//         kSetTankLevel,                  //设置水箱等级
//         kOtaUpgrade,                    //OTA升级
//         kCancelOtaUpgrade,              //取消OTA升级
//         kConnectNetwork,                //配网指令
//         kRemoteControl,                 //虚拟遥控器
//         kSetSideBrushLevel,             //设置边刷等级
//         kFindMachine,                   //寻找机器
//         kClearMap,                      //清除地图
//         kAppointmentTime,               //定时预约
//     }; 
// public:
//     CommandCode code;
//     int deviceLevel;
//     int appointmentTime;

// };

class GetRobotInfoEvent : public Event
{
public:
    GetRobotInfoEvent() {};
};



}


#endif // !APP_COMMAND_H
