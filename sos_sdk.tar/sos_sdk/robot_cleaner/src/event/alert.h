#ifndef ALERT_H
#define ALERT_H
#include <event/event.h>

namespace event {

class Alert : public ExceptionEvent
{
public:
    enum AlertEvent
    {
        ALERT_NONE = 0,            //无
        ALERT_WHEEL_FUALT,         //轮子异常
        ALERT_SIDEBRUSH_FUALT,     //边刷异常
        ALERT_FAN_FUALT,           //风机异常
        ALERT_ROLLBRUSH_FUALT,     //滚刷异常
        ALERT_BOXTANK_FUALT,       //尘盒水箱
        ALERT_OMNIBEARING_FUALT,   //全方位异常
        ALERT_ALONGWALL_FUALT,     //沿墙异常
        ALERT_COLLISION_FUALT,     //碰撞异常
        ALERT_GRDCHECK_FUALT,      //地检异常
        ALERT_ESCAPEJAIL_FAIL,     //脱困失败
        ALERT_DIP_FAIL = 13,       //探底失败
        ALERT_GYRO_FUALT,          //陀螺仪异常
        ALERT_SOFT_POWEROFF = 17,  //软关机
        ALERT_CLEAN_OVER = 19,     //清扫完成
        ALERT_RECHARGE_HOLDER_HID, //未找到回充座
        ALERT_DIP_ESCAPEJAIL_FAIL, //探底脱困失败
        ALERT_MOPSTENTS_REMOVE,    //拖布支架移除
        ALERT_TANKMODE_RUNRANDOM,  //水箱模式运行随机
        ALERT_SLAM_FUALT,          //Slam异常
        ALERT_PROCESS_CRASHES,     //进程死机
        ALERT_RADAR_FUALT,         //雷达异常
    };

public:
    AlertEvent event_;
};


}

#endif // !ALARM_H