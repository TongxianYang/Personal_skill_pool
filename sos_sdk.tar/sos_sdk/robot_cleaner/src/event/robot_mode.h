#ifndef ROBOT_MODE_H 
#define ROBOT_MODE_H

#include <vector>
#include "event.h"
//#include <msgpack.hpp>
//#include "rpc/app_msg.h"

namespace event{

class RobotMode : public InfoEvent
{
public:
    RobotMode()
    {
        mode_event_ = kNoneMode;
        clean_mode_event_ = kNoneCleanMode;
    };
    ~RobotMode(){};
    
    enum ModeEvent{
        kModeInvalid = 0,
        kNoneMode,
        kSleep,
        kStandby,
		kDcCharging, 				
		kChanging,    //回充座充电中
        kChangingBeMove, 
        kWorking,
        kTestMode,
        kWifiSleep,
        kPowerOFF,
    };
    enum CleanModeEvent{
        kCleanModeInvalid = 0,
        kNoneCleanMode,
        kAutoClean,
        kFixedPointClean,
        kAlongWallClean,
        kRandomClean,
        kRecharge,
        kOutTrouble,
        kRemoteControlClean,
        kPartitionZoneClean,
        kKeyRecharge,
        kTestCleanMode,
    };
    enum ChargeModeEvent{
        kLowPowerCharge = 0,       //低电量触发充电模式
        kExternalCmdCharge,        //外部命令触发充电模式（按键或遥控器或app下发充电命令）
    };

public:
    struct Point
    {
        int x; 
        int y;
        //MSGPACK_DEFINE(x, y);
    };
    struct CleanAreaData
    {
        std::vector<Point> Points;
        int area_id;
        //MSGPACK_DEFINE(Points, area_id)
    };
    struct AllAreaData
    {
        int number;
        std::vector<CleanAreaData> area;
        //MSGPACK_DEFINE(number,area);
    };
    struct CleanZoneData
    {
        int zone_mode;
        AllAreaData all_data;
        //MSGPACK_DEFINE(zone_mode,all_data);
    };
public:
    ModeEvent mode_event_;
    CleanModeEvent clean_mode_event_;
    //AppCleanZoneData zone_data;
    ChargeModeEvent charge_mode_event_;
    //AppPointCleanData fixPoint_data;
};

}
#endif // !
