#ifndef EVENT_CONDITION_H
#define EVENT_CONDITION_H

#include "event.h"

namespace event {


class GroundCheckerCondition : public ConditionEvent
{
public:
    enum Condition
    {
        kMachineOnGround = 1,
        kMachinePullup,
        kGroundCheckDirty,
        kGroundCheckCover,
        kLeftCliff,
        kMiddleCliff,
        kRightCliff,
    };
public:
    Condition condition_type;
};

class SideBrushCondition : public ConditionEvent
{
public:
    enum Condition
    {
        
    };
public:
    Condition condition_type;
};

class WheelCondition : public ConditionEvent
{
public:
    enum Condition
    {
        left_locker_rotor,
        right_locker_rotor,
        both_locker_rotor,
    };

public:
    Condition condition_type;
};

}

#endif
