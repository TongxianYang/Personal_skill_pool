#ifndef APP_DEVICE_DATA_H
#define APP_DEVICE_DATA_H
#include "event.h"

namespace event{

class AppDeviceDataEvent : public InfoEvent
{
public:
    enum AppFanLevel
    {
        AppFanTapPotionQuietly,
        AppFanTapPotionLow,
        AppFanTapPotionStandard,
        AppFanTapPotionPowerful,
        AppFanTapPotionMax,
    };

    enum AppTankLevel
    {
        AppTankLevelLow,
        AppTankLevelMiddle,
        AppTankLevelHeight,
    };

    enum DeviceType
    {
        Fan,                  
        tank,                  //
        SideBrush,
    };
public:
    DeviceType event_type;
    int level;

};



}
#endif // 
