#ifndef APPOINTMENT_H
#define APPOINTMENT_H
#include "event.h"
#include <vector>
namespace event {

class Appointment : public ExceptionEvent {

public:
    Appointment()
    {
        event_ = kNone;
    }

    struct AppointmentData
    {
        uint8_t time_zone;      // 手机系统时区  
        uint8_t number;         // 定时条数
        uint8_t effectiveness;  // 是否有效
        uint8_t week;           // 周
        uint8_t hour;           // 小时
        uint8_t min;            // 分钟
        uint8_t room_count;     // 清扫房间数
        uint8_t room_id;        // 房间标识
        uint8_t clean_mode;     //清扫模式
        uint8_t fan_level;       // 风量挡位
        uint8_t water_level;     // 水量挡位
        uint8_t sweep_count;     // 清扫次数
    };

    enum AppointmentEventType{
        kNone,
        syncAppointment,
        deleteAppointment,
        addAppointment,
    };

    AppointmentEventType event_;
    AppointmentData data;
    // std::vector<AppointmentData> data_vector;
};



}


#endif // !APPOINTMENT_H