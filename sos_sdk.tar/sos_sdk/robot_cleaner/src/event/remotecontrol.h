#ifndef REMOTECONTROL_H
#define REMOTECONTROL_H

#include "event.h"

namespace event {
    
class RemoteControl : public InfoEvent
{
public:
    enum RemoteControlCode {
        REMOTECONTROL_IR_NONE,                             //空闲
        REMOTECONTROL_IR_AUTOCLEAN,                        //弓字形清扫
        REMOTECONTROL_IR_AUTOCLEANSTOP,                    //停止弓字形清扫
        REMOTECONTROL_IR_RECHARGE,                         //回充
        REMOTECONTROL_IR_RECHARGESTOP,                     //停止回充
        REMOTECONTROL_IR_ALONGWALLCLEAN,                   //沿墙清扫
        REMOTECONTROL_IR_ALONGWALLCLEANSTOP,               //停止沿墙清扫
        REMOTECONTROL_IR_FIXEDPOINTCLEAN,                  //定点清扫
        REMOTECONTROL_IR_FIXEDPOINTCLEANSTOP,              //停止定点清扫
        REMOTECONTROL_IR_OKSUSPEND,                        //开始、暂停
        REMOTECONTROL_IR_FRONT_KEY,                       //前按键
        REMOTECONTROL_IR_LEFT_KEY,                        //左按键
        REMOTECONTROL_IR_RIGHT_KEY,                       //右按键
        REMOTECONTROL_IR_BEHIND_KEY,                      //后按键
        REMOTECONTROL_IR_FINDSWEEPER,                     //寻找扫地机
        REMOTECONTROL_IR_WATERFANGEARLOW,                 //水量风机低
        REMOTECONTROL_IR_WATERFANGEARMID,                 //水量风机中
        REMOTECONTROL_IR_WATERFANGEARHIGH,                //水量风机高
        REMOTECONTROL_IR_RANDOMCLEAN,                     //随机清扫
        REMOTECONTROL_IR_RANDOMCLEANSTOP,                 //停止随机清扫
        REMOTECONTROL_IR_APPOINTMENTCLEAR,                //预约记录清除      
        REMOTECONTROL_IR_TEST_RUN,                        //跑机台测试
        REMOTECONTROL_IR_TEST_MOTOR,                      //堵转测试
        REMOTECONTROL_IR_PLUS_VOLU,                       //遥控器上+ 风量水箱加
        REMOTECONTROL_IR_LESS_VOLU,                       //遥控器上- 风量水箱减      
        REMOTECONTROL_IR_ARCHCLEAN,                       //弓字形
        REMOTECONTROL_IR_MAP_RECHARGE,                    //地图回充
        REMOTECONTROL_IR_SET_TIME                 = (88)        //遥控器设置当前时间或者设置当前时间
    };

    RemoteControl() {
        code_ = REMOTECONTROL_IR_NONE;
    }
public:
    RemoteControlCode code_;
};

class Gamepad : public InfoEvent
{
public:
    enum GamepadCommand
    {
        kAppGamePadNone = 0,
        kAppGamePadGo,
        kAppGamePadTurnLeft,
        kAppGamePadTurnRight,
        kAppGamePadTurnBack
    };
    GamepadCommand code_;
public:
    Gamepad (){
        code_ = kAppGamePadNone;
    }
};

}

#endif