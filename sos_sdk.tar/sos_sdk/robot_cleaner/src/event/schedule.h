#ifndef SCHEDULE_H
#define SCHEDULE_H
#include <event/event.h>

namespace event {

class Schedule : public InfoEvent
{
public:
    enum ScheduleEvent{
        AppointmentClean,
    };
    
public:
    ScheduleEvent event_;
};


}

#endif // 