#ifndef ROBOT_STASTE_MANAGER_H
#define ROBOT_STASTE_MANAGER_H

#include <mutex>
#include <condition_variable>
//#include <event/event.h>

/*
    this robot state is order to manager to controller the led light and the warning voice;
*/

enum RobotState
{
    kRobotStateClosed = 0,
    kRobotStateStandby,          
    kRobotRunning,
    kRobotPaused,
    kRobotRecharge,
    kRobotOutOffTrouble,
    kRobotWarning,
    kRobotCharging,
    kRobotSleep,
    kRobotDeepsleep,
    kKeyStop,
    kRobotFingerPointClean,
    kRobotFixedPointClean
};


class RobotStateManager 
{
public:
    RobotStateManager();
    ~RobotStateManager(){}
    
    int getNowState();

    bool isStandby();

    bool isWarning();

    bool isRecharge();

    bool isCharging();

    bool isOutOffTrouble();

    bool isDeepSleep();

    bool isRunning();

    bool isKeyStop();

    bool isFixedPointClean();

    bool isFingerPointClean();

    bool changeToRuning();

    bool changerToWarning();

    bool changetToStandby();

    bool changerToCharging();
     
    bool changerToKeyStop(); 

    bool changetToRecharge();

    bool changerToFixedPointClean();

    bool changerToFingerPointClean();

protected:
    void setRobotState(RobotState state);

private:
    volatile RobotState state_;
    
    std::mutex state_lock_;

    std::condition_variable state_condition_;

};

#endif // 
