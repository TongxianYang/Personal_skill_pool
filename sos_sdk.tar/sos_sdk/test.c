#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

static void handle_exit(void)
{
    printf("clean up at process exit\n");
    printf("flush log at process exit\n");
}

int main(int argc, const char *argv[])
{

    atexit(handle_exit);

    pthread_setname_np(pthread_self(), "ancestor");
    while(1) sleep(1);
    //exit(0);
    return 0;
}
