#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include "common_ipc.h"
#include "um_semaphore.h"
#include "logger_rc.h"
#include "logger.h"

LOG_MOD_DECLARE(TAG, DEBUG_IPC);

int ipc_shared_memory_init(ShmObject_t *shm_ob)
{
    /* Create and init Semaphore */
    shm_ob->mutex_sem = semget((key_t)shm_ob->mutex_sem_key, 1, 0666 | IPC_CREAT);
    if (shm_ob->mutex_sem == -1) {
        LOGE(TAG, "semget failed. | errno=%d [%s]", errno, strerror(errno));
        return -1;
    }

    /* Init shared-memory */
    shm_ob->user_shm = shmget((key_t)shm_ob->user_shm_key, shm_ob->mem_size, 0666 | IPC_CREAT);
    if (shm_ob->user_shm == -1) {
        LOGE(TAG, "shmget failed. | errno=%d [%s]", errno, strerror(errno));
        return -1;
    }

    shm_ob->vp_user_shm = shmat(shm_ob->user_shm, (void *)0, 0);
    if (shm_ob->vp_user_shm == (void *)-1) {
        LOGE(TAG, "shmat failed. | errno=%d [%s]", errno, strerror(errno));
        return -1;
    }

    shm_ob->sso_user_shm = (ShmData_t *)shm_ob->vp_user_shm;
    shm_ob->sso_user_shm->end_flag = 1;

    SetSemValue(shm_ob->mutex_sem, 1);

    return 0;
}

int ipc_shared_memory_read(ShmObject_t *shm_ob, char *user_data, int size)
{
    if (-1 == SemaphoreP(shm_ob->mutex_sem))
        return -1;
    memcpy(user_data, (char *)shm_ob->sso_user_shm->data, size);
    while(-1 == SemaphoreV(shm_ob->mutex_sem));

    return 0;
}

int ipc_shared_memory_write(ShmObject_t *shm_ob, char *user_data, int size)
{
    if (-1 == SemaphoreP(shm_ob->mutex_sem))
        return -1;
    memcpy((char *)shm_ob->sso_user_shm->data, user_data, size);
    shm_ob->sso_user_shm->end_flag = 0;
    while(-1 == SemaphoreV(shm_ob->mutex_sem));

    return 0;
}

