#ifndef __LOGGER_RC_H__
#define __LOGGER_RC_H__

/**
 * Unified debug log specification,
 * different modules to print a different label
 * and will print func name and line
 * Instructions, such as airkiss module want add a print
 * LOGE(DEBUG_TEST,"hello workld ...\n")
 * you can set debug_mask value
 * to choose which module need to print
 * if you need to add more modules,
 * please refer to the original way
 */

enum {
    DEBUG_IPC   = 0,
};

#define DEBUG_DESC_IPC      "Ipc"

#endif /* __LOGGER_RC_H__ */
