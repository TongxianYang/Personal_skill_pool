/*
 * @Author: DahlMill
 * @Date: 2020-03-04 10:56:13
 * @LastEditTime: 2020-10-02 10:48:41
 * @LastEditors: Please set LastEditors
 * @Description: 
 * @FilePath: /shmYuv/Semaphore.h
 */

#ifndef __SEMAPHORE_H__
#define __SEMAPHORE_H__

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

int SetSemValue(int sem_id, int value);
void DelSemValue(int sem_id);
int SemaphoreP(int sem_id);
int SemaphoreV(int sem_id);

#endif