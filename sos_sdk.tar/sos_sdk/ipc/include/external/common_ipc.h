#ifndef __COMMON_IPC_H__
#define __COMMON_IPC_H__

#include <sys/msg.h>
#include <sys/shm.h>
#include <sys/sem.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int end_flag;       // 0: 未结束, 1: 结束
    char data[320];
} ShmData_t;

typedef struct {
    int mutex_sem;
    key_t mutex_sem_key;
    int user_shm;
    key_t user_shm_key;
    int mem_size;
    void *vp_user_shm;
    ShmData_t *sso_user_shm;
} ShmObject_t;

int ipc_shared_memory_init(ShmObject_t *shm_ob);
int ipc_shared_memory_read(ShmObject_t *shm_ob, char *user_data, int size);
int ipc_shared_memory_write(ShmObject_t *shm_ob, char *user_data, int size);

#ifdef __cplusplus
}
#endif

#endif /* __COMMON_IPC_H__ */
