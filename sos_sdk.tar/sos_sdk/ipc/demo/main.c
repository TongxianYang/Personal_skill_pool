#include <stdio.h>
#include "common_ipc.h"
#include "logger_rc.h"
#include "logger.h"

LOG_MOD_DECLARE(TAG, DEBUG_IPC);

char rd_buffer[32] = {0};
char wr_buffer[32] = "hello world!";

int main(int argc, const char *argv[])
{
    if (argc < 2) {
        return 0;
    }

    const ModLogDef_t mod_array[] = {
	    {DEBUG_IPC, DEBUG_DESC_IPC}
    };

    logger_init(mod_array, sizeof(mod_array)/sizeof(ModLogDef_t), NULL);
    logger_level(ELEVEL_TRACE);

    ShmObject_t shm_ob = {0};

    shm_ob.mutex_sem = -1;
    shm_ob.mutex_sem_key = 3331;
    shm_ob.user_shm = -1;
    shm_ob.user_shm_key = 3331;
    shm_ob.mem_size = sizeof(rd_buffer);
    shm_ob.vp_user_shm = NULL;
    shm_ob.sso_user_shm = NULL;
    ipc_shared_memory_init(&shm_ob);

    if (atoi(argv[1]) == 0) {
        ipc_shared_memory_read(&shm_ob, rd_buffer, sizeof(rd_buffer));
        LOGD(TAG, "read --- rd_buffer = %s", rd_buffer);
    }

    if (atoi(argv[1]) == 1) {
        ipc_shared_memory_write(&shm_ob, wr_buffer, sizeof(wr_buffer));
        LOGD(TAG, "write --- wr_buffer = %s", wr_buffer);
    }

    LOGD(TAG, "logger test success!");
    LOGT(TAG, "yangtongxian!");

    return 0;
}

