#ifndef MSG_HEADER_H
#define MSG_HEADER_H

#ifdef __cplusplus
namespace core {
extern "C" {
#endif

enum {
    kHeaderRequest = 'Q',
    kHeaderResponse = 'S'
};

struct header {
    int type;
    int seq;
    int data_type;
    int data_len;
};

#ifdef __cplusplus
}
}
#endif

#endif
