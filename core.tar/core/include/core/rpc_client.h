#ifndef RPC_CLIENT_H
#define RPC_CLIENT_H

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <string>

namespace core {

class RpcClient
{
public:
    RpcClient();

    void setServerAddress(std::string server_address);

    bool connect();

    void disconnect();

protected:
    virtual void handleNewConnection(int fd);

private:
    std::string server_address;
    int client_socket;
    struct sockaddr_un server_sockaddr;
};

}

#endif
