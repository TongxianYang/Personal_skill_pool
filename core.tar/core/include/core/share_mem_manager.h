#ifndef SHARE_MEM_MANAGER_H_
#define SHARE_MEM_MANAGER_H_

#include <sys/types.h>

#ifdef __cplusplus
namespace core {
extern "C" {
#endif

void *share_mem_alloc(const char *name, size_t size);
void share_mem_free(void *p, const char *name, int size);

#ifdef __cplusplus
}
}
#endif

#endif
