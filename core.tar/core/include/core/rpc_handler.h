#ifndef SKELETON_THREAD_H
#define SKELETON_THREAD_H

#include <map>
#include <mutex>
#include <memory>
#include <thread>
#include <vector>
#include <future>

#include <core/queue.h>
#include <core/header.h>

namespace core {

class RpcHandler
{
public:
    class RpcQueueData {
    public:
        int seq;
        bool send;
        bool recv;
        struct core::header header;
        std::vector<char> packed_data;
        bool has_promise;
        std::shared_ptr<std::promise<bool>> promise;
    };

    class PromiseContext {
    public:
        int seq;
        std::shared_ptr<std::promise<bool>> promise;
    };

public:
    RpcHandler() {
        seq = 0;
    }

    void setSocketFd(int fd) {
        this->fd = fd;
    }

    void start();

    void stop();

    bool isRunning();

protected:
    virtual bool threadSendLoop();
    virtual bool threadRecvLoop();

    int generateSeq();
    void submitToSendQueue(std::shared_ptr<RpcQueueData> request);

private:
    void threadSendFunction();
    void threadRecvFunction();

protected:
    int fd;
    std::shared_ptr<std::thread> send_thread_;
    std::shared_ptr<std::thread> recv_thread_;
    volatile bool send_running_;
    volatile bool recv_running_;
    int seq;
    std::mutex seq_mutex;
    core::Queue<std::shared_ptr<RpcQueueData>> send_queue;
    std::condition_variable event_condition_;
    std::mutex event_mutex_;
    std::map<int, std::shared_ptr<PromiseContext>> promise_map;
};

}

#endif
