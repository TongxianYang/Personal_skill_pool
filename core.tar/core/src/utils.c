#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <time.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <pthread.h>
#include <unistd.h>

#include <core/log.h>
#include <core/utils.h>

// #define BUFSIZ  128
static const char *TAG = "utils";

#define TYPE_WIDTH(t) (sizeof (t) * CHAR_BIT)
#define TYPE_MINIMUM(t) ((t) ~ TYPE_MAXIMUM (t))
#define TYPE_SIGNED(t) (! ((t) 0 < (t) -1))
#define TYPE_MAXIMUM(t)                                                 \
  ((t) (! TYPE_SIGNED (t)                                               \
        ? (t) -1                                                        \
        : ((((t) 1 << (TYPE_WIDTH (t) - 2)) - 1) * 2 + 1)))


int exec_cmd(const char *cmd)
{
    int status;
    int ret;

    log_info(TAG, "exec %s start", cmd);
    status = system(cmd);
    if (status == -1) {
        log_error("system exec %s", cmd);
        return -1;
    } else {
        ret = WEXITSTATUS(status);
        if (ret) {
            log_error("exec %s failed ret=%d", cmd, ret);
            return ret;
        } else {
            log_info(TAG, "exec %s success", cmd);
            return 0;
        }
    }
}

int popen_cmd(const char *cmd)
{
    int ret;
    int status;
    char tmp_buf[BUFSIZ];

    if (snprintf(tmp_buf, sizeof(tmp_buf), "%s 2>&1", cmd) > sizeof(tmp_buf)) {
        return -EINVAL;
    }

    log_info(TAG, "popen %s", tmp_buf);
    FILE *p = popen(tmp_buf, "r");
    if (!p) {
        log_error("popen %s failed", tmp_buf);
        return -ENOMEM;
    }

    log_info(TAG, "exec %s output:\n", cmd);
    while (fgets(tmp_buf, sizeof(tmp_buf), p) != NULL) {
        log_info(TAG, "\t%s", tmp_buf);
    }

    status = pclose(p);
    if (status == -1) {
        log_error("popen exec %s failed errno %d", cmd, errno);
        return -1;
    } else {
        ret = WEXITSTATUS(status);
        if (ret) {
            log_error("popen %s failed ret=%d", cmd, ret);
            return ret;
        } else {
            log_info(TAG, "popen %s success", cmd);
            return 0;
        }
    }
}

int64_t get_unix_timestamp_ms()
{
    struct timeval tp;
    gettimeofday(&tp, NULL);
    int64_t ms = tp.tv_sec * 1000 + tp.tv_usec / 1000;
    return ms;
}

uint32_t get_uptime()
{
    int rc;
    struct timespec tp;

    rc = clock_gettime(CLOCK_BOOTTIME, &tp);
    if (rc) {
        log_error(TAG, "%s: get boottime failed", __func__);
        return 0;
    }

    return (uint32_t)tp.tv_sec + (uint32_t)round(tp.tv_nsec / (1000*1000*1000));
}

uint64_t get_uptime_ms()
{
    uint64_t ms;
    int rc;
    struct timespec tp;

    rc = clock_gettime(CLOCK_BOOTTIME, &tp);
    if (rc) {
        log_error(TAG, "%s: get boottime failed", __func__);
        return 0;
    }

    ms = tp.tv_sec * 1000 + tp.tv_nsec / (1000*1000);

    return ms; 
}

int msleep(int ms)
{
    int second;
    int millisecond;
    struct timespec tim;

    second = ms / 1000;
    millisecond = ms % 1000;
    tim.tv_sec = second;
    tim.tv_nsec = millisecond * 1000 * 1000;

    // log_info(TAG, "msleep sec=%ld nsec=%ld", tim.tv_sec, tim.tv_nsec);
    if(nanosleep(&tim , NULL) < 0 )   
    {
        log_error(TAG, "msleep failed");
        return -1;
    }

    return 0;
}

struct tm *get_now_time(void)
{
    time_t t;
    struct tm *tm = NULL;

    time(&t);
    tm = localtime(&t);
    if (NULL == tm)
            return NULL;

    return tm;
}

uint32_t get_current_time(void)
{
    int rc;
    struct timespec tp;

    rc = clock_gettime(CLOCK_REALTIME, &tp);
    if (rc) {
        log_error(TAG, "%s: get boottime failed", __func__);
        return 0;
    }

    return (uint32_t)tp.tv_sec + (uint32_t)round(tp.tv_nsec / (1000*1000*1000));
}
