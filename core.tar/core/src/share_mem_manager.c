#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <string.h>

#include <core/log.h>
#include <core/share_mem_manager.h>

static const char *TAG = "share_mem";

#define MAX_NAME    (64)

void *share_mem_alloc(const char *name, size_t size)
{
    int rc;
    int fd;
    void *p;
    char path_name[MAX_NAME];

    rc = snprintf(path_name, sizeof(path_name), "/%s", name);
    if (rc > sizeof(path_name)) {
        return NULL;
    }

    fd = shm_open(path_name, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        return NULL;
    }
    rc = ftruncate(fd, size);
    if (rc) {
        return NULL;
    }

    p = mmap(NULL, size, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) {
        return NULL;
    }

    // log_hexdump_with_hint(name, p, size);

    return p;
}

void share_mem_free(void *p, const char *name, int size)
{
    char path_name[MAX_NAME];
    int rc;
    if (NULL == p)
        return;

    rc = snprintf(path_name, sizeof(path_name), "/%s", name);
    if (rc > sizeof(path_name)) {
        return;
    }
    if (0 == munmap(p, size))
    {
        if (-1 == shm_unlink(path_name))
        {
            log_error(TAG, "shm_unlink failed: %s", strerror(errno));
        }
    } else {
        log_info(TAG, "munmap failed");
    }
}
