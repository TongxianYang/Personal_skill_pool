#include <stdarg.h>
#include <fmt/format.h>
#include "spdlog/spdlog.h"
#include "spdlog/fmt/bin_to_hex.h"
#include "spdlog/async.h"
#include "spdlog/sinks/basic_file_sink.h"
#include "spdlog/sinks/rotating_file_sink.h"
#include "spdlog/sinks/stdout_color_sinks.h"

#include <core/log.h>

#define MSG_BUF_MAX_LEN (256)

static std::shared_ptr<spdlog::logger> logger;
static std::shared_ptr<spdlog::logger> timer_logger;
static std::shared_ptr<spdlog::logger> map_logger;
static std::shared_ptr<spdlog::logger> parent_logger;
static std::shared_ptr<spdlog::logger> robot_logger;

namespace core {

int log_init_default()
{
    // mt - mutex locked version
    // st - lock free version
    // logger = spdlog::rotating_logger_mt<spdlog::async_factory>("file_logger", "um_laser_iot_spd.log", 1024 * 1024 * 5, 1);
    // logger = spdlog::rotating_logger_mt("iot", "/mnt/UDISK/logs/iot_spd.log", 1024 * 1024 * 2, 2);
    logger = spdlog::rotating_logger_st("iot", "/mnt/UDISK/logs/robot_controller.log", 1024 * 1024 * 2, 2);
    // logger = spdlog::basic_logger_mt<spdlog::async_factory>("file_logger", "um_laser_iot_spd.log");
    if (logger == nullptr)
        return -1;

    spdlog::set_default_logger(logger);
    spdlog::flush_on(spdlog::level::debug);

    logger->info("spdlog init success");
    // printf("spdlog init success\n");

    return 0;
}

int log_init(const char *name, const char *path)
{
    if (!name) {
        return -1;
    }

    if (!path) {
        logger = spdlog::stdout_color_mt(name);
    } else {
        logger = spdlog::rotating_logger_mt(name, path, 1024 * 1024 * 2, 2);
    }

    if (logger == nullptr)
        return -1;

    spdlog::set_default_logger(logger);
    spdlog::flush_on(spdlog::level::debug);

    logger->info("spdlog init success");
    printf("spdlog init success\n");
    return 0;
}

void log_enable()
{
    // FIXME: do it better
    logger->set_level(spdlog::level::info);
}

void log_disable()
{
    logger->set_level(spdlog::level::off);
}

int log_init(const char *name, const char *path, std::shared_ptr<spdlog::logger> &logger)
{
    if (!name) {
        return -1;
    }

    if (!path) {
        logger = spdlog::stdout_color_mt(name);
    } else {
        logger = spdlog::rotating_logger_mt(name, path, 1024 * 1024 * 2, 2);
    }

    if (logger == nullptr)
        return -1;

    spdlog::set_default_logger(logger);
    spdlog::flush_on(spdlog::level::debug);

    logger->info("spdlog init %s success", name);
    printf("spdlog init %s success\n", name);

    return 0;
}

int log_init_for_robot()
{
    return log_init("robot", "/mnt/UDISK/logs/robot_spd.log", robot_logger);
}

void log_robot_info(const char* fmt, ...)
{
    int rc;
    char msgbuf[MSG_BUF_MAX_LEN];
    va_list args;

    va_start(args, fmt);
    rc = vsnprintf(msgbuf, sizeof(msgbuf), fmt, args);
    va_end(args);

    if (rc > MSG_BUF_MAX_LEN) {
        std::string msg = msgbuf + std::string("[truncated]");
        robot_logger->info(msg.c_str());
    } else {
        robot_logger->info(msgbuf);
    }
}

int log_init_for_timer()
{
    return log_init("timer", "/mnt/UDISK/logs/timer_spd.log", timer_logger);
}

void log_timer_info(const char* fmt, ...)
{
    int rc;
    char msgbuf[MSG_BUF_MAX_LEN];
    va_list args;

    va_start(args, fmt);
    rc = vsnprintf(msgbuf, sizeof(msgbuf), fmt, args);
    va_end(args);

    if (rc > MSG_BUF_MAX_LEN) {
        std::string msg = msgbuf + std::string("[truncated]");
        timer_logger->info(msg.c_str());
    } else {
        timer_logger->info(msgbuf);
    }
}

int log_init_for_map()
{
    return log_init("map", "/mnt/UDISK/logs/map_spd.log", map_logger);
}

void log_map_info(const char* fmt, ...)
{
    int rc;
    char msgbuf[MSG_BUF_MAX_LEN];
    va_list args;

    va_start(args, fmt);
    rc = vsnprintf(msgbuf, sizeof(msgbuf), fmt, args);
    va_end(args);

    if (rc > MSG_BUF_MAX_LEN) {
        std::string msg = msgbuf + std::string("[truncated]");
        map_logger->info(msg.c_str());
    } else {
        map_logger->info(msgbuf);
    }
}

int log_init_for_parent()
{
    return log_init("parent", "/mnt/UDISK/logs/parent_spd.log", parent_logger);
}

void log_parent_info(const char* fmt, ...)
{
    int rc;
    char msgbuf[MSG_BUF_MAX_LEN];
    va_list args;

    va_start(args, fmt);
    rc = vsnprintf(msgbuf, sizeof(msgbuf), fmt, args);
    va_end(args);

    if (rc > MSG_BUF_MAX_LEN) {
        std::string msg = msgbuf + std::string("[truncated]");
        parent_logger->info(msg.c_str());
    } else {
        parent_logger->info(msgbuf);
    }
}

void log_debug(const char *tag, const char* fmt, ...)
{
    int rc;
    char msgbuf[MSG_BUF_MAX_LEN];
    va_list args;

    va_start(args, fmt);
    rc = vsnprintf(msgbuf, sizeof(msgbuf), fmt, args);
    va_end(args);

    if (rc > MSG_BUF_MAX_LEN) {
        // std::string msg = msgbuf + std::string("[truncated]");
        logger->debug(fmt::format("[{}] {} [truncated]", tag, msgbuf));
    } else {
        logger->debug(fmt::format("[{}] {}", tag, msgbuf));
    }
}

void log_info(const char *tag, const char* fmt, ...)
{
    int rc;
    char msgbuf[MSG_BUF_MAX_LEN];
    va_list args;

    va_start(args, fmt);
    rc = vsnprintf(msgbuf, sizeof(msgbuf), fmt, args);
    va_end(args);

    if (rc > MSG_BUF_MAX_LEN) {
        // std::string msg = msgbuf + std::string("[truncated]");
        logger->info(fmt::format("[{}] {} [truncated]", tag, msgbuf));
    } else {
        logger->info(fmt::format("[{}] {}", tag, msgbuf));
    }
}

void log_warn(const char *tag, const char* fmt, ...)
{
    int rc;
    char msgbuf[MSG_BUF_MAX_LEN];
    va_list args;

    va_start(args, fmt);
    rc = vsnprintf(msgbuf, sizeof(msgbuf), fmt, args);
    va_end(args);

    if (rc > MSG_BUF_MAX_LEN) {
        // std::string msg = msgbuf + std::string("[truncated]");
        logger->warn(fmt::format("[{}] {} [truncated]", tag, msgbuf));
    } else {
        logger->warn(fmt::format("[{}] {}", tag, msgbuf));
    }
}

void log_error(const char *tag, const char* fmt, ...)
{
    int rc;
    char msgbuf[MSG_BUF_MAX_LEN];
    va_list args;

    va_start(args, fmt);
    rc = vsnprintf(msgbuf, sizeof(msgbuf), fmt, args);
    va_end(args);

    if (rc > MSG_BUF_MAX_LEN) {
        // std::string msg = msgbuf + std::string("[truncated]");
        logger->error(fmt::format("[{}] {} [truncated]", tag, msgbuf));
    } else {
        logger->error(fmt::format("[{}] {}", tag, msgbuf));
    }
}

void log_flush()
{
    logger->flush();
}

void log_hexdump(void *buf, int size)
{
    char *p = (char *)buf;
    std::vector<char> tbuf(size);

    for (int i = 0; i < size; i++)
    {
        tbuf.push_back(p[i]);
    }
    // spdlog::info("Binary example: {}", spdlog::to_hex(buf));
    logger->info("hexdump: {:a}", spdlog::to_hex(tbuf));
}

void log_hexdump_with_hint(const char *hint, void *buf, int size)
{
    char *p = (char *)buf;
    std::vector<char> tbuf(size);

    for (int i = 0; i < size; i++)
    {
        tbuf.push_back(p[i]);
    }
    // spdlog::info("Binary example: {}", spdlog::to_hex(buf));
    if (hint) {
        std::string hs(hint);
        logger->info("{}: {:a}", hs, spdlog::to_hex(tbuf));
    } else {
        logger->info("hexdump: {:a}", spdlog::to_hex(tbuf));
    }
}

}
