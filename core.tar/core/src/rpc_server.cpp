#include <unistd.h>
#include <string.h>
#include <core/log.h>
#include <core/rpc_server.h>

static const char *TAG = "rpc_server";

namespace core {

RpcServer::RpcServer()
{
    server_socket = 0;
}

bool RpcServer::init()
{
    int rc;
    int len;
    const char *bind_address = server_address.c_str();

    memset(&server_sockaddr, 0, sizeof(struct sockaddr_un));

    server_socket = socket(AF_UNIX, SOCK_STREAM, 0);
    if (server_socket == -1){
        log_error(TAG, "create socket failed");
        return false;
    }

    server_sockaddr.sun_family = AF_UNIX;   
    strcpy(server_sockaddr.sun_path, bind_address); 
    len = sizeof(server_sockaddr);
    
    unlink(bind_address);
    rc = bind(server_socket, (struct sockaddr *) &server_sockaddr, len);
    if (rc == -1){
        log_error(TAG, "bind to address %s failed", bind_address);
        close(server_socket);
        return false;
    }

    rc = listen(server_socket, 5);
    if (rc == -1){ 
        log_error(TAG, "listen error");
        close(server_socket);
        return false;
    }

    return true;
}

void RpcServer::exit()
{
    if (server_socket > 0) {
        int rc;
        rc = shutdown(server_socket, SHUT_RDWR);
        if (rc) {
            log_error(TAG, "shutdown rpc server failed");
        }
    }
}

void RpcServer::setServerAddress(std::string server_address)
{
    this->server_address = server_address;
}

bool RpcServer::threadLoop()
{
    int rc;
    int len;
    int client_socket;
    struct sockaddr_un client_sockaddr;

    len = sizeof(client_sockaddr);
    client_socket = accept(server_socket, (struct sockaddr *)&client_sockaddr, (socklen_t *)&len);
    if (client_socket == -1){
        log_error(TAG, "accpet clinet failed:%s", strerror(errno));
        close(server_socket);
        return false;
    }

    handleNewConnection(client_socket);

    return true;
}

void RpcServer::handleNewConnection(int fd)
{

}

}
