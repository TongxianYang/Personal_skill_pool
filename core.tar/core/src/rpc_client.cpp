#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/socket.h>

#include <core/log.h>
#include <core/rpc_client.h>


static const char *TAG = "rpc_client";

namespace core {

RpcClient::RpcClient()
{

}

void RpcClient::setServerAddress(std::string server_address)
{
    this->server_address = server_address;
}

bool RpcClient::connect()
{
    int rc;
    int len;

    client_socket = socket(AF_UNIX, SOCK_STREAM, 0);
    if (client_socket == -1) {
        log_error(TAG, "create client socket failed:%s", strerror(errno));
        return false;
    }

    len = sizeof(server_sockaddr);
    server_sockaddr.sun_family = AF_UNIX;
    strcpy(server_sockaddr.sun_path, server_address.c_str());
    rc = ::connect(client_socket, (struct sockaddr *) &server_sockaddr, (socklen_t)len);
    if(rc == -1){
        log_error(TAG, "connect to server socket failed:%s", strerror(errno));
        close(client_socket);
        return false;
    }

    handleNewConnection(client_socket);

    return true;
}

void RpcClient::disconnect()
{

}

void RpcClient::handleNewConnection(int fd)
{

}

}
