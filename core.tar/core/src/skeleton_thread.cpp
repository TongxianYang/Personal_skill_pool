#include <typeinfo>
#include <spdlog/spdlog.h>
// #include <folly/system/ThreadName.h>

#include <core/log.h>
#include <core/skeleton_thread.h>

static const char *TAG = "skeleton_thread";

namespace core {

SkeletonThread::SkeletonThread()
{
    running_ = false;
}

SkeletonThread::~SkeletonThread()
{
    if (running_) {
        log_info(TAG, "Thread %s still running at destructor, stop and join", name_.c_str());
        stop();
    }
}

// void SkeletonThread::setThreadName(std::string name)
// {
//     thread_name_ = name;

//     if (running_) {
//         if (!thread_name_.empty()) {
//             SPDlog_info(TAG, "set thread name {} for {}", thread_name_, name_);
//             if (!folly::setThreadName(thread_name_)) {
//                 SPDLOG_ERROR("set thread name {} failed", thread_name_);
//             }
//         }
//     }
// }

void SkeletonThread::start()
{
    thread_ = std::make_shared<std::thread>(&SkeletonThread::threadFunction, this);
    log_info(TAG, "start thread id 0x%08x\n", thread_->get_id());
}

void SkeletonThread::stop()
{
    if (running_) {
        running_ = false;
        onStop();
        log_info(TAG, "exit thread id 0x%08x\n", thread_->get_id());
        thread_->join();
        thread_ = nullptr;
    }
}

bool SkeletonThread::isRunning()
{
    return running_;
}

void SkeletonThread::threadFunction()
{
    bool exec;

    name_ = typeid(*this).name();

    running_ = true;

    // SPDlog_info(TAG, "Service {} thread start", name_);
    log_info(TAG, "Service %s thread start", name_.c_str());

    std::string tmp_name;
    if (name_.size() > 15) {
        tmp_name = name_.substr(0, 15);
    } else {
        tmp_name = name_;
    }
    pthread_setname_np(pthread_self(), tmp_name.c_str());

    // if (!thread_name_.empty()) {
    //     SPDlog_info(TAG, "set thread name {} for {}", thread_name_, name_);
    //     if (!folly::setThreadName(thread_name_)) {
    //         SPDLOG_ERROR("set thread name {} failed", thread_name_);
    //     }
    // }

    onStart();

    while (running_) {
        exec = threadLoop();
        if (!exec) {
            break;
        }
    }

    // SPDlog_info(TAG, "Service {} thread stop", name_);
    log_info(TAG, "Service %s thread stop", name_.c_str());

    onStop();
}

void SkeletonThread::onStart()
{

}

void SkeletonThread::onStop()
{

}

bool SkeletonThread::threadLoop()
{
    return false;
}

}
