#include <unistd.h>

#include <core/log.h>
#include <core/rpc_handler.h>


static const char *TAG = "rpc_handler";

namespace core {

void RpcHandler::start()
{
    send_thread_ = std::make_shared<std::thread>(&RpcHandler::threadSendFunction, this);
    log_info(TAG, "start send thread id 0x%08x\n", send_thread_->get_id());
    recv_thread_ = std::make_shared<std::thread>(&RpcHandler::threadRecvFunction, this);
    log_info(TAG, "start recv thread id 0x%08x\n", recv_thread_->get_id());
}

void RpcHandler::stop()
{
    if (send_running_) {
        send_running_ = false;
        
        log_info(TAG, "exit send thread id 0x%08x\n", send_thread_->get_id());
        send_thread_->join();
        send_thread_ = nullptr;
    }

    if (recv_running_) {
        recv_running_ = false;
    
        log_info(TAG, "exit recv thread id 0x%08x\n", recv_thread_->get_id());
        recv_thread_->join();
        recv_thread_ = nullptr;
    }
}

bool RpcHandler::isRunning()
{
    return send_running_ && recv_running_;
}

bool RpcHandler::threadSendLoop()
{
    int rc;
    bool success;
    bool got_reqeust;
    std::shared_ptr<RpcQueueData> request;

    {
        std::unique_lock<std::mutex> lock(event_mutex_);
        got_reqeust = event_condition_.wait_for(lock, std::chrono::milliseconds(100),  [&] {
            return send_queue.size() != 0;
        });

        if (got_reqeust == false) {
            return true;
        }
    }

    success = send_queue.dequeue(request);
    if (success == false) {
        log_error(TAG, "got task from task queue failed");
        return true;
    }

    // write request to fd..
    rc = write(fd, &request->header, sizeof(request->header));
    if (rc < 0) {
        log_info(TAG, "write request header failed");
        return false;
    }

    if (request->header.data_len) {
        rc = write(fd, (void *)request->packed_data.data(), request->packed_data.size());
        if (rc < 0) {
            log_info(TAG, "write request data failed");
            return false;
        }
    }

    if (request->has_promise) {
        auto context = std::make_shared<PromiseContext>();
        context->seq = request->seq;
        context->promise = request->promise;
        promise_map[request->seq] = context;
    }

    return true;
}

bool RpcHandler::threadRecvLoop()
{
    return false;
}

void RpcHandler::threadSendFunction()
{
    bool exec;

    send_running_ = true;

    while (send_running_) {
        exec = threadSendLoop();
        if (!exec) {
            break;
        }
    }

    log_info(TAG, "send thread id 0x%08x stopped\n", send_thread_->get_id());
}

void RpcHandler::threadRecvFunction()
{
    bool exec;

    recv_running_ = true;

    while (recv_running_) {
        exec = threadRecvLoop();
        if (!exec) {
            break;
        }
    }

    log_info(TAG, "recv thread id 0x%08x stopped\n", recv_thread_->get_id());
}

int RpcHandler::generateSeq()
{
    std::unique_lock<std::mutex> lck(seq_mutex);

    return seq++;
}

void RpcHandler::submitToSendQueue(std::shared_ptr<RpcQueueData> request)
{
    bool success;
    std::unique_lock<std::mutex> lck(event_mutex_);

    success = send_queue.enqueue(request);
    if (success) {
        event_condition_.notify_all();
    } else {
        log_error(TAG, "enqueue faield");
    }
}

}